# 学生选课成绩管理系统 - 完成总结

## 系统状态

| 项目 | 状态 | 说明 |
| --- | --- | --- |
| 前端 | 已完成 | Vue 3 + Vite + Element Plus |
| 后端 | 已完成 | Node.js + Express |
| 数据库 | 已迁移 | 华为云 GaussDB/openGauss |
| 鉴权 | 已完成 | 三类角色 Token 鉴权 |
| 数据库对象 | 已完成 | 触发器 + 存储过程 |

## 用户角色

- 系统管理员：学生、教师、课程、选课、退课、成绩、统计管理。
- 学生：查看个人信息、自主选课、退课、查询课程和成绩统计。
- 教师：查看授课课程、录入成绩、维护教学日志、查看教学统计。

## 数据库结构

迁移后的数据库使用 6 张核心表：

- `admin`
- `student`
- `teacher`
- `course`
- `enrollment`
- `teaching_log`

数据库脚本位于 `database/schema-final.sql` 和 `database/sp-select-course.sql`，包含：

- 触发器：自动维护课程已选人数，并维护教学日志更新时间。
- 存储过程：`sp_select_course`，封装选课校验和写入逻辑。
- 示例数据：管理员、学生、教师、课程、选课记录、教学日志。

## 启动方式

```bash
cp backend/.env.example backend/.env
# 填写华为云 GaussDB/openGauss 连接信息
bash full-init.sh
./launch.sh
```

## 验收情况

- B/S 架构：已完成。
- 三类角色权限：已完成。
- 管理员教务管理：已完成。
- 学生自主选课和查询：已完成。
- 教师成绩录入和教学管理：已完成。
- 多角色统计分析：已完成。
- 触发器和存储过程：已完成并在系统接口中使用。
- 华为云 GaussDB/openGauss 迁移：已完成代码与脚本适配，需填入真实云数据库连接信息后执行初始化。
