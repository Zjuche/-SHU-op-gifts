# 学生选课成绩管理系统 - 最终版本

## 访问方式

```bash
./launch.sh
```

前端默认地址：`http://localhost:5173`

后端默认地址：`http://localhost:3000/api`

## 测试账号

- 管理员：`admin` / `123456`
- 学生：`2023001` / `123456`
- 教师：`T001` / `123456`

## 核心功能

- 三类用户登录和权限控制。
- 管理员维护学生、教师、课程、选课、退课、成绩。
- 学生按学期自主选课、退课、查询成绩和学习统计。
- 教师录入成绩、维护教学日志、查看课程统计。
- 系统提供学生、课程、教师维度统计分析。
- 数据库包含触发器和存储过程，并已接入业务流程。

## 数据库版本

当前版本已从本地 MySQL 迁移到华为云 GaussDB/openGauss。

迁移说明：`docs/gaussdb-migration.md`

华为数据库自学报告：`docs/huawei-db-report.md`

初始化脚本：`database/schema-final.sql`

本地 openGauss 实践：`docs/local-opengauss-practice.md`
