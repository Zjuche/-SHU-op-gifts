# 学生选课成绩管理系统 🎓

> 基于教材《PowerBuilder 2018 数据库应用开发简介》第 13 章实验五
> 使用现代技术栈实现的完整教务管理系统

---

## 📋 项目概述

这是一个功能完善的**学生选课成绩管理系统**，支持三类用户角色，采用前后端分离架构，使用签名 Token 进行身份验证。
系统数据库迁移到华为云 GaussDB/openGauss，采用云端关系数据库保存教学事务数据。

### ✨ 核心特性

- ✅ **三类用户**: 管理员、学生、教师
- ✅ **签名 Token 鉴权**: 安全的 Token 认证机制
- ✅ **路由守卫**: 基于角色的访问控制
- ✅ **完整 CRUD**: 学生、课程、教师管理
- ✅ **选课管理**: 在线选课、退课、按学期筛选课程
- ✅ **成绩管理**: 教师录分、学生查询
- ✅ **数据统计**: 学生/课程/教师成绩分析
- ✅ **学期管理**: 课程按学期展示、统计与查询
- ✅ **数据库对象**: 触发器自动维护选课人数，存储过程负责选课提交
- ✅ **华为云数据库**: 使用 GaussDB/openGauss 云端持久化

---

## 🎯 用户角色

### 1️⃣ 管理员 (admin)

**登录**: `admin` / `123456`

**功能**:
- 📊 仪表盘 - 系统统计信息
- 👨‍🎓 学生管理 - 增删改查学生
- 👨‍🏫 教师管理 - 增删改查教师
- 📚 课程管理 - 增删改查课程、维护学期
- ➕ 选课管理 - 为学生选课
- ➖ 退课管理 - 为学生退课
- 📝 成绩管理 - 录入/修改成绩
- 📈 统计查询 - 成绩与教师统计分析

### 2️⃣ 学生 (student)

**登录**: `2023001`-`2023004` / `123456`

**功能**:
- 👤 个人中心 - 查看个人信息
- 📚 我的课程 - 查看已选课程
- ➕ 选课 - 在线选课并按学期筛选
- ➖ 退课 - 退选课程
- 📊 成绩查询 - 查看个人成绩
- 📈 学习统计 - 查看学分、平均分、成绩分布

### 3️⃣ 教师 (teacher)

**登录**: `T001`-`T003` / `123456`

**功能**:
- 👤 个人中心 - 查看个人信息
- 📚 所授课程 - 查看授课列表并切换学期
- 📝 成绩录入 - 录入学生成绩
- 📒 教学日志 - 记录课堂内容、课后任务和备注
- 📈 统计分析 - 查看课程表现、学期汇总和近期日志

---

## 🏗️ 技术栈

### 前端

- **Vue 3** - 渐进式 JavaScript 框架
- **Vite** - 下一代前端构建工具
- **Element Plus** - Vue 3 UI 组件库
- **Pinia** - Vue 状态管理
- **Vue Router** - 路由管理
- **Axios** - HTTP 客户端

### 后端

- **Node.js** - JavaScript 运行时
- **Express** - Web 应用框架
- **pg** - GaussDB/openGauss 兼容连接驱动
- **dotenv** - 环境变量管理

### 数据库

- **华为云 GaussDB/openGauss** - 云端关系型数据库
- **表结构**: 6 个核心表，含教学日志表

---

## 📊 数据库表

```
admin        - 管理员表 (1 条)
student      - 学生表 (4 条)
teacher      - 教师表 (3 条)
course       - 课程表 (4 条)
enrollment   - 选课表 (7 条)
teaching_log - 教学日志表 (4 条)
```

---

## 🚀 快速开始

### 1. 启动数据库

**方式一：本地 Docker OpenGauss（推荐开发环境）**

```bash
cd /media/kevin0412/Data/database_course/student_manage_system

# 首次启动（创建并运行容器）
OPENGAUSS_PASSWORD=请替换为数据库强密码 docker compose -f docker-compose.opengauss.yml up -d

# 后续启动（容器已存在但处于停止状态）
docker start student-opengauss
```

**方式二：华为云 GaussDB/openGauss**

在华为云创建 GaussDB/openGauss 实例和目标 database，然后在 `backend/.env` 中填写云端连接信息。

### 2. 数据库初始化

```bash
cp backend/.env.example backend/.env
# 编辑 backend/.env，填写数据库连接信息（若使用本地 Docker，默认配置已可用）
bash full-init.sh
```

`full-init.sh` 脚本会在目标 database 中创建表、触发器、存储过程和演示数据。

### 3. 启动服务

**方式一**: 使用一键启动脚本

```bash
./launch.sh
```

**方式二**: 手动启动

```bash
# 后端 (终端 1)
cd backend
npm run dev

# 前端 (终端 2)
cd frontend
npm run dev
```

### 3. 访问系统

- **前端**: http://localhost:5173
- **后端 API**: http://localhost:3000/api

---

## 📁 项目结构

```
student_manage_system/
├── backend/                    # Express 后端
│   ├── src/
│   │   ├── app.js             # 应用入口
│   │   ├── config/
│   │   │   └── database.js    # 数据库配置
│   │   └── routes/
│   │       └── index.js       # 路由定义
│   ├── .env                   # 环境配置
│   └── package.json
│
├── frontend/                   # Vue 3 前端
│   ├── src/
│   │   ├── views/             # 页面组件
│   │   │   ├── Login.vue      # 登录页面
│   │   │   ├── main/          # 主布局
│   │   │   ├── student/       # 学生页面
│   │   │   ├── teacher/       # 教师页面
│   │   │   └── admin/         # 管理员页面
│   │   ├── router/            # 路由配置
│   │   ├── stores/            # 状态管理
│   │   │   └── auth.js        # 用户状态
│   │   └── api/               # API 接口
│   ├── .env
│   └── package.json
│
├── database/
│   ├── schema-final.sql       # GaussDB/openGauss 数据库脚本
│   └── sp-select-course.sql   # openGauss 选课存储过程
│
├── docker-compose.opengauss.yml # 本地/云服务器 openGauss 容器配置
├── requirements.md            # 项目要求
├── docs/
│   ├── gaussdb-migration.md   # GaussDB 迁移说明
│   ├── cloud-deploy.md        # 云服务器部署说明
│   ├── huawei-db-report.md    # 华为数据库自学报告
│   └── local-opengauss-practice.md # 本地 openGauss 实践记录
├── README.md                  # 本文档
├── launch.sh                  # 启动脚本
└── stop.sh                    # 停止脚本
```

---

## 🧪 测试场景

### 管理员测试

1. 登录 `admin`
2. 查看仪表盘统计
3. 添加/修改/删除学生
4. 添加/修改/删除课程
5. 为学生选课
6. 为课程录入成绩
7. 查看统计数据

### 学生测试

1. 登录 `2023001`
2. 查看个人信息
3. 查看已选课程
4. 切换学期并选择新课程
5. 退选课程
6. 查看个人成绩

### 教师测试

1. 登录 `T001`
2. 查看所授课程并切换学期
3. 录入学生成绩
4. 查看课程统计与教学统计

---

## 📝 API 接口

### 认证

- `POST /api/login` - 用户登录

### 学生管理

- `GET /api/students` - 获取学生列表
- `POST /api/students` - 添加学生

### 教师管理

- `GET /api/teachers` - 获取教师列表
- `POST /api/teachers` - 添加教师

### 课程管理

- `GET /api/courses` - 获取课程列表
- `POST /api/courses` - 添加课程

### 选课管理

- `GET /api/enrollments` - 获取选课记录
- `POST /api/enrollments` - 选课
- `DELETE /api/enrollments/:id` - 退课
- `PUT /api/enrollments/:id/score` - 更新成绩

### 统计

- `GET /api/statistics` - 获取统计数据
- `GET /api/student/statistics` - 获取当前学生学习统计
- `GET /api/teacher/statistics` - 获取当前教师教学统计

### 教学日志

- `GET /api/teaching-logs` - 获取教学日志
- `POST /api/teaching-logs` - 新增教学日志
- `PUT /api/teaching-logs/:id` - 修改教学日志
- `DELETE /api/teaching-logs/:id` - 删除教学日志

---

## 🎨 界面预览

### 登录页面

- 居中卡片设计
- 三类用户角色切换
- 默认密码提示
- Loading 状态

### 主布局

- 左侧导航菜单（根据角色动态加载）
- 顶部用户信息
- 响应式内容区

---

## ✅ 验收标准

- [x] 支持三类用户登录
- [x] 签名 Token 鉴权
- [x] 路由守卫和权限控制
- [x] 完整的数据库表结构
- [x] 触发器和存储过程投入使用
- [x] 所有功能模块可用
- [x] 数据持久化到华为云 GaussDB/openGauss
- [x] API 接口完整
- [x] 前端页面完整

---

## 📞 技术支持

- **教材**: 《PowerBuilder 2018 数据库应用开发简介》
- **章节**: 第 13 章 实验五
- **项目**: 学生选课成绩管理系统

---

## 📄 License

MIT License

---

**系统已就绪！访问 http://localhost:5173 开始使用 🚀**
