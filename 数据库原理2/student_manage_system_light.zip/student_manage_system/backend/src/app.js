import express from 'express'
import cors from 'cors'
import { config } from 'dotenv'
import { testConnection } from './config/database.js'
import { router } from './routes/index.js'

config({ path: '.env' })

const app = express()
const port = Number(process.env.PORT || 3000)

app.use(cors())
app.use(express.json())
app.use('/api', router)

app.get('/', (req, res) => {
  res.json({
    message: '学生选课成绩管理系统后端服务运行中',
    database: process.env.DB_NAME || 'school'
  })
})

// 启动服务器
async function startServer() {
  const server = app.listen(port, () => {
    console.log(`\n${'='.repeat(60)}`)
    console.log('  学生选课成绩管理系统 - 后端服务')
    console.log('  Student Course Management System - Backend')
    console.log('='.repeat(60))
    console.log(`\n  服务运行在：http://localhost:${port}`)
    console.log(`  API 地址：http://localhost:${port}/api`)
    console.log(`  数据库：${process.env.DB_NAME || 'school'}`)
    console.log('='.repeat(60))
  })

  // 测试数据库连接
  console.log('\n正在连接数据库...')
  const connected = await testConnection()
  
  if (!connected) {
    console.log('\n⚠ 数据库连接失败，除健康检查外的接口可能不可用')
    console.log('  如需使用华为云 GaussDB/openGauss，请先初始化数据库')
    console.log('  运行命令：bash full-init.sh\n')
  }
}

startServer()
