import pg from 'pg';
import { config } from 'dotenv';

config({ path: '.env' });

const { Pool, types } = pg;

types.setTypeParser(20, (value) => Number(value));
types.setTypeParser(1700, (value) => Number(value));
types.setTypeParser(1082, (value) => value);
types.setTypeParser(1114, (value) => value);
types.setTypeParser(1184, (value) => value);

const sslMode = String(process.env.DB_SSL || process.env.PGSSLMODE || 'disable').toLowerCase();
const useSsl = ['true', '1', 'require', 'prefer', 'verify-ca', 'verify-full'].includes(sslMode);
const ssl = useSsl
  ? { rejectUnauthorized: process.env.DB_SSL_REJECT_UNAUTHORIZED !== 'false' }
  : false;

const pgPool = new Pool({
  host: process.env.DB_HOST || process.env.PGHOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || process.env.PGPORT || 5432),
  user: process.env.DB_USER || process.env.PGUSER || 'student_user',
  password: process.env.DB_PASSWORD || process.env.PGPASSWORD,
  database: process.env.DB_NAME || process.env.PGDATABASE || 'school',
  ssl,
  max: Number(process.env.DB_POOL_SIZE || 10),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

const toPgPlaceholders = (sql = '') => {
  let index = 0;
  return String(sql).replace(/\?/g, () => `$${++index}`);
};

const normalizeError = (error) => {
  if (!error) return error;
  error.sqlMessage = error.message;
  return error;
};

const pool = {
  async query(sql, params = []) {
    try {
      const result = await pgPool.query(toPgPlaceholders(sql), params);

      if (result.command === 'SELECT') {
        return [result.rows, result.fields];
      }

      return [{
        affectedRows: result.rowCount,
        insertId: result.rows?.[0]?.id ?? null,
        rows: result.rows,
      }, result.fields];
    } catch (error) {
      throw normalizeError(error);
    }
  },

  async end() {
    await pgPool.end();
  },
};

async function testConnection() {
  try {
    const client = await pgPool.connect();
    const result = await client.query('SELECT current_database() AS database, version() AS version');
    client.release();

    console.log('✓ GaussDB/openGauss 数据库连接成功');
    console.log('  database:', result.rows[0]?.database);
    console.log('  host:', process.env.DB_HOST || process.env.PGHOST || '127.0.0.1');
    console.log('  port:', process.env.DB_PORT || process.env.PGPORT || 5432);
    return true;
  } catch (error) {
    console.error('✗ GaussDB/openGauss 数据库连接失败:', error.message);
    return false;
  }
}

export { pool, testConnection };
