import { Router } from 'express';
import { pool } from '../config/database.js';
import { createToken, verifyToken } from '../utils/jwt.js';
import { getCurrentSemester } from '../utils/semester.js';

const router = Router();

// 辅助函数
const ok = (res, data = null, message = '操作成功') => res.json({ code: 0, message, data });
const fail = (res, message = '操作失败', status = 400) => res.status(status).json({ code: 1, message });
const nowString = () => new Date().toLocaleString('zh-CN', { hour12: false }).replaceAll('/', '-');
const normalizeText = (value) => String(value ?? '').trim();
const getBearerToken = (header = '') => {
  if (!header) return '';
  const [scheme, token] = String(header).split(' ');
  return scheme === 'Bearer' ? token : '';
};

const auth = (roles = []) => (req, res, next) => {
  try {
    const token = getBearerToken(req.headers.authorization);
    if (!token) {
      return fail(res, '请先登录', 401);
    }

    const payload = verifyToken(token);
    req.auth = payload;

    if (roles.length > 0 && !roles.includes(payload.role)) {
      return fail(res, '无权限访问此功能', 403);
    }

    next();
  } catch (error) {
    return fail(res, '登录已过期，请重新登录', 401);
  }
};

const ensureTeacherCourse = async (teacherId, courseId) => {
  const [rows] = await pool.query(
    'SELECT course_id FROM course WHERE teacher_id = ? AND course_id = ?',
    [teacherId, courseId]
  );
  return rows.length > 0;
};

// 健康检查
router.get('/health', (req, res) => {
  ok(res, { status: 'ok', time: nowString() }, '服务正常');
});

// 登录验证（支持三类用户）
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return fail(res, '用户名和密码不能为空', 400);
    }
    
    // 1. 验证管理员
    const [admins] = await pool.query(
      'SELECT * FROM admin WHERE username = ? AND password = ?',
      [username, password]
    );
    
    if (admins.length > 0) {
      const admin = admins[0];
      return ok(res, { 
        role: 'admin',
        name: admin.name,
        username: admin.username,
        token: createToken({
          role: 'admin',
          name: admin.name,
          username: admin.username,
        })
      }, '登录成功');
    }
    
    // 2. 验证学生（学号作为用户名）
    const [students] = await pool.query(
      'SELECT * FROM student WHERE student_id = ?',
      [username]
    );
    
    if (students.length > 0 && (students[0].password ?? '123456') === password) {
      const student = students[0];
      return ok(res, { 
        role: 'student',
        name: student.name,
        student_id: student.student_id,
        class_name: student.class_name,
        major: student.major,
        token: createToken({
          role: 'student',
          name: student.name,
          student_id: student.student_id,
          class_name: student.class_name,
          major: student.major,
        })
      }, '登录成功');
    }
    
    // 3. 验证教师（教师工号作为用户名）
    const [teachers] = await pool.query(
      'SELECT * FROM teacher WHERE teacher_id = ?',
      [username]
    );
    
    if (teachers.length > 0 && (teachers[0].password ?? '123456') === password) {
      const teacher = teachers[0];
      return ok(res, { 
        role: 'teacher',
        name: teacher.name,
        teacher_id: teacher.teacher_id,
        department: teacher.department,
        title: teacher.title,
        token: createToken({
          role: 'teacher',
          name: teacher.name,
          teacher_id: teacher.teacher_id,
          department: teacher.department,
          title: teacher.title,
        })
      }, '登录成功');
    }
    
    // 登录失败
    return fail(res, '用户名或密码错误', 401);
    
  } catch (error) {
    console.error('登录错误:', error);
    return fail(res, '服务器错误', 500);
  }
});

// 首页统计信息（管理员专用）
router.get('/dashboard', auth(['admin']), async (req, res) => {
  try {
    const [studentCount] = await pool.query('SELECT COUNT(*) as count FROM student');
    const [teacherCount] = await pool.query('SELECT COUNT(*) as count FROM teacher');
    const [courseCount] = await pool.query('SELECT COUNT(*) as count FROM course');
    const [semesterCount] = await pool.query('SELECT COUNT(DISTINCT semester) as count FROM course');
    const [enrollmentCount] = await pool.query('SELECT COUNT(*) as count FROM enrollment');
    const [scoreRows] = await pool.query(
      'SELECT COUNT(*) as count, AVG(score) as avg_score FROM enrollment WHERE score IS NOT NULL'
    );
    
    const averageScore = scoreRows[0].avg_score !== null
      ? Number(scoreRows[0].avg_score).toFixed(1)
      : '0.0';
    
    ok(res, {
      studentCount: studentCount[0].count,
      teacherCount: teacherCount[0].count,
      courseCount: courseCount[0].count,
      semesterCount: semesterCount[0].count,
      enrollmentCount: enrollmentCount[0].count,
      scoreCount: scoreRows[0].count,
      averageScore
    });
  } catch (error) {
    console.error('获取统计信息错误:', error);
    fail(res, '获取统计信息失败', 500);
  }
});

// ==================== 学生管理 ====================

// 获取学生列表
router.get('/students', auth(['admin']), async (req, res) => {
  try {
    const { student_id, name } = req.query;
    
    let sql = 'SELECT * FROM student';
    let params = [];
    
    if (student_id || name) {
      sql += ' WHERE 1=1';
      if (student_id) {
        sql += ' AND student_id = ?';
        params.push(student_id);
      }
      if (name) {
        sql += ' AND name LIKE ?';
        params.push(`%${name}%`);
      }
    }
    
    const [rows] = await pool.query(sql, params);
    ok(res, rows);
  } catch (error) {
    console.error('获取学生列表错误:', error);
    fail(res, '获取学生列表失败', 500);
  }
});

// 添加学生
router.post('/students', auth(['admin']), async (req, res) => {
  try {
    const { student_id, name, gender, age, class_name, major, phone } = req.body;
    
    if (!student_id || !name || !class_name || !major) {
      return fail(res, '学生信息不完整', 400);
    }
    
    const [existing] = await pool.query(
      'SELECT * FROM student WHERE student_id = ?',
      [student_id]
    );
    
    if (existing.length > 0) {
      return fail(res, '学号已存在', 400);
    }
    
    await pool.query(
      'INSERT INTO student (student_id, name, gender, age, class_name, major, phone) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [student_id, name, gender || '男', age || 0, class_name, major, phone || '']
    );
    
    ok(res, { id: student_id, student_id }, '学生添加成功');
  } catch (error) {
    console.error('添加学生错误:', error);
    fail(res, '添加学生失败', 500);
  }
});

// 修改学生
router.put('/students/:id', auth(['admin']), async (req, res) => {
  try {
    const { name, gender, age, class_name, major, phone } = req.body;
    await pool.query(
      'UPDATE student SET name=?, gender=?, age=?, class_name=?, major=?, phone=? WHERE student_id=?',
      [name, gender, age, class_name, major, phone, req.params.id]
    );
    ok(res, null, '修改成功');
  } catch (error) {
    console.error('修改学生错误:', error);
    fail(res, '修改学生失败', 500);
  }
});

// 删除学生
router.delete('/students/:id', auth(['admin']), async (req, res) => {
  try {
    await pool.query('DELETE FROM enrollment WHERE student_id=?', [req.params.id]);
    await pool.query('DELETE FROM student WHERE student_id=?', [req.params.id]);
    ok(res, null, '删除成功');
  } catch (error) {
    console.error('删除学生错误:', error);
    fail(res, '删除学生失败', 500);
  }
});

// ==================== 教师管理 ====================

// 获取教师列表
router.get('/teachers', auth(['admin']), async (req, res) => {
  try {
    const { teacher_id, name } = req.query;
    
    let sql = 'SELECT * FROM teacher';
    let params = [];
    
    if (teacher_id || name) {
      sql += ' WHERE 1=1';
      if (teacher_id) {
        sql += ' AND teacher_id = ?';
        params.push(teacher_id);
      }
      if (name) {
        sql += ' AND name LIKE ?';
        params.push(`%${name}%`);
      }
    }
    
    const [rows] = await pool.query(sql, params);
    ok(res, rows);
  } catch (error) {
    console.error('获取教师列表错误:', error);
    fail(res, '获取教师列表失败', 500);
  }
});

// 添加教师
router.post('/teachers', auth(['admin']), async (req, res) => {
  try {
    const { teacher_id, name, gender, title, department, phone } = req.body;
    
    if (!teacher_id || !name) {
      return fail(res, '教师信息不完整', 400);
    }
    
    const [existing] = await pool.query(
      'SELECT * FROM teacher WHERE teacher_id = ?',
      [teacher_id]
    );
    
    if (existing.length > 0) {
      return fail(res, '教师工号已存在', 400);
    }
    
    await pool.query(
      'INSERT INTO teacher (teacher_id, name, gender, title, department, phone) VALUES (?, ?, ?, ?, ?, ?)',
      [teacher_id, name, gender || null, title || null, department || '', phone || '']
    );
    
    ok(res, { id: teacher_id, teacher_id }, '教师添加成功');
  } catch (error) {
    console.error('添加教师错误:', error);
    fail(res, '添加教师失败', 500);
  }
});

// 修改教师
router.put('/teachers/:id', auth(['admin']), async (req, res) => {
  try {
    const { name, gender, title, department, phone } = req.body;
    await pool.query(
      'UPDATE teacher SET name=?, gender=?, title=?, department=?, phone=? WHERE teacher_id=?',
      [name, gender, title, department, phone, req.params.id]
    );
    ok(res, null, '修改成功');
  } catch (error) {
    console.error('修改教师错误:', error);
    fail(res, '修改教师失败', 500);
  }
});

// 删除教师
router.delete('/teachers/:id', auth(['admin']), async (req, res) => {
  try {
    const [courses] = await pool.query('SELECT course_id FROM course WHERE teacher_id=?', [req.params.id]);
    if (courses.length > 0) {
      return fail(res, '该教师有关联课程，请先删除相关课程', 400);
    }
    await pool.query('DELETE FROM teacher WHERE teacher_id=?', [req.params.id]);
    ok(res, null, '删除成功');
  } catch (error) {
    console.error('删除教师错误:', error);
    fail(res, '删除教师失败', 500);
  }
});

// ==================== 课程管理 ====================

// 获取课程列表
router.get('/courses', auth(), async (req, res) => {
  try {
    let { course_id, course_name, teacher_id } = req.query;

    if (req.auth.role === 'teacher') {
      teacher_id = req.auth.teacher_id;
    } else if (req.auth.role === 'student') {
      teacher_id = undefined;
    }
    
    let sql = `
      SELECT c.*, t.name AS teacher_name
      FROM course c
      LEFT JOIN teacher t ON c.teacher_id = t.teacher_id
    `;
    let params = [];
    
    if (course_id || course_name || teacher_id) {
      sql += ' WHERE 1=1';
      if (course_id) {
        sql += ' AND c.course_id = ?';
        params.push(course_id);
      }
      if (course_name) {
        sql += ' AND c.course_name LIKE ?';
        params.push(`%${course_name}%`);
      }
      if (teacher_id) {
        sql += ' AND c.teacher_id = ?';
        params.push(teacher_id);
      }
    }
    
    const [rows] = await pool.query(sql, params);
    ok(res, rows);
  } catch (error) {
    console.error('获取课程列表错误:', error);
    fail(res, '获取课程列表失败', 500);
  }
});

// 添加课程
router.post('/courses', auth(['admin']), async (req, res) => {
  try {
    const { course_id, course_name, credit, teacher_id, semester, max_students, classroom } = req.body;
    
    if (!course_id || !course_name || !teacher_id) {
      return fail(res, '课程信息不完整', 400);
    }
    
    const [existing] = await pool.query(
      'SELECT * FROM course WHERE course_id = ?',
      [course_id]
    );
    
    if (existing.length > 0) {
      return fail(res, '课程号已存在', 400);
    }
    
    const [teacherRows] = await pool.query(
      'SELECT name FROM teacher WHERE teacher_id = ?',
      [teacher_id]
    );

    if (teacherRows.length === 0) {
      return fail(res, '任课教师不存在', 400);
    }

    const resolvedSemester = normalizeText(semester) || getCurrentSemester();

    await pool.query(
      'INSERT INTO course (course_id, course_name, credit, teacher_id, teacher_name, semester, max_students, classroom) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [course_id, course_name, credit || 0, teacher_id, teacherRows[0].name, resolvedSemester, max_students || 50, classroom || '']
    );
    
    ok(res, { id: course_id, course_id }, '课程添加成功');
  } catch (error) {
    console.error('添加课程错误:', error);
    fail(res, '添加课程失败', 500);
  }
});

// 修改课程
router.put('/courses/:id', auth(['admin']), async (req, res) => {
  try {
    const { course_name, credit, teacher_id, semester, max_students, classroom } = req.body;
    const [existing] = await pool.query(
      'SELECT semester FROM course WHERE course_id = ?',
      [req.params.id]
    );

    if (existing.length === 0) {
      return fail(res, '课程不存在', 404);
    }

    if (!teacher_id) {
      return fail(res, '请选择任课教师', 400);
    }

    const [teacherRows] = await pool.query(
      'SELECT name FROM teacher WHERE teacher_id = ?',
      [teacher_id]
    );

    if (teacherRows.length === 0) {
      return fail(res, '任课教师不存在', 400);
    }

    const resolvedSemester = normalizeText(semester) || existing[0].semester || getCurrentSemester();
    await pool.query(
      'UPDATE course SET course_name=?, credit=?, teacher_id=?, teacher_name=?, semester=?, max_students=?, classroom=? WHERE course_id=?',
      [course_name, credit, teacher_id, teacherRows[0].name, resolvedSemester, max_students, classroom, req.params.id]
    );
    ok(res, null, '修改成功');
  } catch (error) {
    console.error('修改课程错误:', error);
    fail(res, '修改课程失败', 500);
  }
});

// 删除课程
router.delete('/courses/:id', auth(['admin']), async (req, res) => {
  try {
    await pool.query('DELETE FROM enrollment WHERE course_id=?', [req.params.id]);
    await pool.query('DELETE FROM course WHERE course_id=?', [req.params.id]);
    ok(res, null, '删除成功');
  } catch (error) {
    console.error('删除课程错误:', error);
    fail(res, '删除课程失败', 500);
  }
});

// ==================== 选课管理 ====================

// 获取选课记录
router.get('/enrollments', auth(), async (req, res) => {
  try {
    let { student_id, course_id, teacher_id } = req.query;

    if (req.auth.role === 'student') {
      student_id = req.auth.student_id;
      course_id = undefined;
      teacher_id = undefined;
    } else if (req.auth.role === 'teacher') {
      student_id = undefined;
      course_id = undefined;
      teacher_id = req.auth.teacher_id;
    }
    
    let sql = `
      SELECT
        e.id,
        e.student_id,
        e.course_id,
        e.semester,
        to_char(e.select_time, 'YYYY-MM-DD HH24:MI:SS') AS select_time,
        e.score,
        s.name AS student_name,
        c.course_name,
        t.name AS teacher_name
      FROM enrollment e
      JOIN student s ON e.student_id = s.student_id
      JOIN course c ON e.course_id = c.course_id
      LEFT JOIN teacher t ON c.teacher_id = t.teacher_id
    `;
    let params = [];
    
    if (student_id) {
      sql += ' WHERE e.student_id = ?';
      params.push(student_id);
    } else if (course_id) {
      sql += ' WHERE e.course_id = ?';
      params.push(course_id);
    } else if (teacher_id) {
      sql += ` WHERE c.teacher_id = ?`;
      params.push(teacher_id);
    }
    
    const [rows] = await pool.query(sql, params);
    ok(res, rows);
  } catch (error) {
    console.error('获取选课记录错误:', error);
    fail(res, '获取选课记录失败', 500);
  }
});

// 选课
router.post('/enrollments', auth(['admin', 'student']), async (req, res) => {
  try {
    const { student_id, course_id } = req.body;
    
    if (!student_id || !course_id) {
      return fail(res, '学号和课程号不能为空', 400);
    }

    if (req.auth.role === 'student' && req.auth.student_id !== student_id) {
      return fail(res, '无权限为其他学生选课', 403);
    }
    
    await pool.query('CALL sp_select_course(?, ?)', [student_id, course_id]);

    ok(res, { student_id, course_id }, '选课成功');
  } catch (error) {
    console.error('选课错误:', error);
    fail(res, error.sqlMessage || error.message || '选课失败', 400);
  }
});

// 退课
router.delete('/enrollments/:id', auth(['admin', 'student']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    
    const [existing] = await pool.query(
      'SELECT * FROM enrollment WHERE id = ?',
      [id]
    );
    
    if (existing.length === 0) {
      return fail(res, '选课记录不存在', 404);
    }

    if (req.auth.role === 'student' && existing[0].student_id !== req.auth.student_id) {
      return fail(res, '无权限退选其他学生的课程', 403);
    }
    
    await pool.query(
      'DELETE FROM enrollment WHERE id = ?',
      [id]
    );
    
    ok(res, null, '退课成功');
  } catch (error) {
    console.error('退课错误:', error);
    fail(res, '退课失败', 500);
  }
});

// ==================== 成绩管理 ====================

// 更新成绩
router.put('/enrollments/:id/score', auth(['admin', 'teacher']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { score } = req.body;
    
    if (score === undefined || score === null || score < 0 || score > 100) {
      return fail(res, '成绩必须在 0-100 之间', 400);
    }
    
    const [existing] = await pool.query(
      'SELECT * FROM enrollment WHERE id = ?',
      [id]
    );
    
    if (existing.length === 0) {
      return fail(res, '选课记录不存在', 404);
    }

    if (req.auth.role === 'teacher') {
      const [teacherRows] = await pool.query(
        `
        SELECT c.teacher_id
        FROM enrollment e
        JOIN course c ON e.course_id = c.course_id
        WHERE e.id = ?
        `,
        [id]
      );

      if (teacherRows.length === 0 || teacherRows[0].teacher_id !== req.auth.teacher_id) {
        return fail(res, '无权限修改其他教师课程成绩', 403);
      }
    }
    
    const [result] = await pool.query(
      'UPDATE enrollment SET score = ? WHERE id = ?',
      [score, id]
    );
    
    if (result.affectedRows === 0) {
      return fail(res, '成绩更新失败', 500);
    }
    
    ok(res, { id, score }, '成绩保存成功');
  } catch (error) {
    console.error('更新成绩错误:', error);
    fail(res, '成绩更新失败', 500);
  }
});

// ==================== 学生统计 ====================

// 获取当前学生学习统计
router.get('/student/statistics', auth(['student']), async (req, res) => {
  try {
    const studentId = req.auth.student_id;

    const [overviewRows] = await pool.query(
      `
      SELECT
        COUNT(e.id) AS course_count,
        COUNT(e.score) AS scored_count,
        ROUND(COALESCE(AVG(e.score), 0), 1) AS avg_score,
        MAX(e.score) AS max_score,
        MIN(e.score) AS min_score,
        ROUND(COALESCE(SUM(c.credit), 0), 1) AS selected_credit,
        ROUND(COALESCE(SUM(CASE WHEN e.score >= 60 THEN c.credit ELSE 0 END), 0), 1) AS passed_credit,
        ROUND(
          COALESCE(
            SUM(CASE WHEN e.score >= 60 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(e.score), 0),
            0
          ),
          1
        ) AS pass_rate
      FROM enrollment e
      JOIN course c ON e.course_id = c.course_id
      WHERE e.student_id = ?
      `,
      [studentId]
    );

    const [semesterStats] = await pool.query(
      `
      SELECT
        e.semester,
        COUNT(e.id) AS course_count,
        ROUND(COALESCE(SUM(c.credit), 0), 1) AS credit_sum,
        ROUND(COALESCE(AVG(e.score), 0), 1) AS avg_score,
        COUNT(e.score) AS scored_count
      FROM enrollment e
      JOIN course c ON e.course_id = c.course_id
      WHERE e.student_id = ?
      GROUP BY e.semester
      ORDER BY e.semester DESC
      `,
      [studentId]
    );

    const [gradeDistribution] = await pool.query(
      `
      SELECT grade_band, COUNT(*) AS count
      FROM (
        SELECT
          CASE
            WHEN e.score IS NULL THEN '未录入'
            WHEN e.score >= 90 THEN '优秀'
            WHEN e.score >= 80 THEN '良好'
            WHEN e.score >= 70 THEN '中等'
            WHEN e.score >= 60 THEN '及格'
            ELSE '未及格'
          END AS grade_band
        FROM enrollment e
        WHERE e.student_id = ?
      ) bands
      GROUP BY grade_band
      ORDER BY CASE grade_band
        WHEN '优秀' THEN 1
        WHEN '良好' THEN 2
        WHEN '中等' THEN 3
        WHEN '及格' THEN 4
        WHEN '未及格' THEN 5
        ELSE 6
      END
      `,
      [studentId]
    );

    const [courseGrades] = await pool.query(
      `
      SELECT
        e.id,
        e.course_id,
        c.course_name,
        e.semester,
        c.credit,
        c.teacher_name,
        e.score
      FROM enrollment e
      JOIN course c ON e.course_id = c.course_id
      WHERE e.student_id = ?
      ORDER BY e.semester DESC, e.course_id
      `,
      [studentId]
    );

    ok(res, {
      overview: overviewRows[0],
      semesterStats,
      gradeDistribution,
      courseGrades
    });
  } catch (error) {
    console.error('获取学生统计错误:', error);
    fail(res, '获取学生统计失败', 500);
  }
});

// ==================== 教师统计 ====================

// 获取当前教师教学统计
router.get('/teacher/statistics', auth(['teacher']), async (req, res) => {
  try {
    const teacherId = req.auth.teacher_id;

    const [overviewRows] = await pool.query(
      `
      SELECT
        COUNT(DISTINCT c.course_id) AS course_count,
        COUNT(e.id) AS enrollment_count,
        COUNT(e.score) AS scored_count,
        ROUND(COALESCE(AVG(e.score), 0), 1) AS avg_score,
        ROUND(
          COALESCE(
            SUM(CASE WHEN e.score >= 60 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(e.score), 0),
            0
          ),
          1
        ) AS pass_rate
      FROM course c
      LEFT JOIN enrollment e ON c.course_id = e.course_id
      WHERE c.teacher_id = ?
      `,
      [teacherId]
    );

    const [courseStats] = await pool.query(
      `
      SELECT
        c.course_id,
        c.course_name,
        c.semester,
        c.credit,
        c.selected_count,
        c.max_students,
        COUNT(e.id) AS enrollment_count,
        COUNT(e.score) AS scored_count,
        ROUND(COALESCE(AVG(e.score), 0), 1) AS avg_score,
        MAX(e.score) AS max_score,
        MIN(e.score) AS min_score,
        ROUND(
          COALESCE(
            SUM(CASE WHEN e.score >= 60 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(e.score), 0),
            0
          ),
          1
        ) AS pass_rate
      FROM course c
      LEFT JOIN enrollment e ON c.course_id = e.course_id
      WHERE c.teacher_id = ?
      GROUP BY c.course_id, c.course_name, c.semester, c.credit, c.selected_count, c.max_students
      ORDER BY c.semester DESC, c.course_id
      `,
      [teacherId]
    );

    const [semesterStats] = await pool.query(
      `
      SELECT
        c.semester,
        COUNT(DISTINCT c.course_id) AS course_count,
        COUNT(e.id) AS enrollment_count,
        COUNT(e.score) AS scored_count,
        ROUND(COALESCE(AVG(e.score), 0), 1) AS avg_score
      FROM course c
      LEFT JOIN enrollment e ON c.course_id = e.course_id
      WHERE c.teacher_id = ?
      GROUP BY c.semester
      ORDER BY c.semester DESC
      `,
      [teacherId]
    );

    const [recentLogs] = await pool.query(
      `
      SELECT
        l.id,
        l.course_id,
        c.course_name,
        to_char(l.teaching_date, 'YYYY-MM-DD') AS teaching_date,
        l.topic
      FROM teaching_log l
      JOIN course c ON l.course_id = c.course_id
      WHERE l.teacher_id = ?
      ORDER BY l.teaching_date DESC, l.id DESC
      LIMIT 8
      `,
      [teacherId]
    );

    ok(res, {
      overview: overviewRows[0],
      courseStats,
      semesterStats,
      recentLogs
    });
  } catch (error) {
    console.error('获取教师统计错误:', error);
    fail(res, '获取教师统计失败', 500);
  }
});

// ==================== 教学日志 ====================

// 获取教学日志
router.get('/teaching-logs', auth(['admin', 'teacher']), async (req, res) => {
  try {
    let { teacher_id, course_id } = req.query;

    if (req.auth.role === 'teacher') {
      teacher_id = req.auth.teacher_id;
    }

    let sql = `
      SELECT
        l.id,
        l.teacher_id,
        l.course_id,
        to_char(l.teaching_date, 'YYYY-MM-DD') AS teaching_date,
        l.topic,
        l.content,
        l.homework,
        l.remark,
        l.created_at,
        l.updated_at,
        c.course_name,
        c.semester,
        t.name AS teacher_name
      FROM teaching_log l
      JOIN course c ON l.course_id = c.course_id
      JOIN teacher t ON l.teacher_id = t.teacher_id
      WHERE 1=1
    `;
    const params = [];

    if (teacher_id) {
      sql += ' AND l.teacher_id = ?';
      params.push(teacher_id);
    }

    if (course_id) {
      sql += ' AND l.course_id = ?';
      params.push(course_id);
    }

    sql += ' ORDER BY l.teaching_date DESC, l.id DESC';

    const [rows] = await pool.query(sql, params);
    ok(res, rows);
  } catch (error) {
    console.error('获取教学日志错误:', error);
    fail(res, '获取教学日志失败', 500);
  }
});

// 新增教学日志
router.post('/teaching-logs', auth(['teacher']), async (req, res) => {
  try {
    const { course_id, teaching_date, topic, content, homework, remark } = req.body;
    const teacherId = req.auth.teacher_id;

    if (!course_id || !teaching_date || !normalizeText(topic)) {
      return fail(res, '课程、日期和主题不能为空', 400);
    }

    if (!(await ensureTeacherCourse(teacherId, course_id))) {
      return fail(res, '无权限为该课程登记教学日志', 403);
    }

    const [result] = await pool.query(
      `
      INSERT INTO teaching_log (teacher_id, course_id, teaching_date, topic, content, homework, remark)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      RETURNING id
      `,
      [
        teacherId,
        course_id,
        teaching_date,
        normalizeText(topic),
        normalizeText(content),
        normalizeText(homework),
        normalizeText(remark)
      ]
    );

    ok(res, { id: result.insertId }, '教学日志已保存');
  } catch (error) {
    console.error('新增教学日志错误:', error);
    fail(res, error.sqlMessage || '新增教学日志失败', 400);
  }
});

// 修改教学日志
router.put('/teaching-logs/:id', auth(['teacher']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { course_id, teaching_date, topic, content, homework, remark } = req.body;
    const teacherId = req.auth.teacher_id;

    if (!course_id || !teaching_date || !normalizeText(topic)) {
      return fail(res, '课程、日期和主题不能为空', 400);
    }

    const [existing] = await pool.query(
      'SELECT id FROM teaching_log WHERE id = ? AND teacher_id = ?',
      [id, teacherId]
    );

    if (existing.length === 0) {
      return fail(res, '教学日志不存在或无权限修改', 404);
    }

    if (!(await ensureTeacherCourse(teacherId, course_id))) {
      return fail(res, '无权限为该课程登记教学日志', 403);
    }

    await pool.query(
      `
      UPDATE teaching_log
      SET course_id = ?, teaching_date = ?, topic = ?, content = ?, homework = ?, remark = ?
      WHERE id = ? AND teacher_id = ?
      `,
      [
        course_id,
        teaching_date,
        normalizeText(topic),
        normalizeText(content),
        normalizeText(homework),
        normalizeText(remark),
        id,
        teacherId
      ]
    );

    ok(res, { id }, '教学日志已更新');
  } catch (error) {
    console.error('修改教学日志错误:', error);
    fail(res, error.sqlMessage || '修改教学日志失败', 400);
  }
});

// 删除教学日志
router.delete('/teaching-logs/:id', auth(['teacher']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [result] = await pool.query(
      'DELETE FROM teaching_log WHERE id = ? AND teacher_id = ?',
      [id, req.auth.teacher_id]
    );

    if (result.affectedRows === 0) {
      return fail(res, '教学日志不存在或无权限删除', 404);
    }

    ok(res, null, '教学日志已删除');
  } catch (error) {
    console.error('删除教学日志错误:', error);
    fail(res, '删除教学日志失败', 500);
  }
});

// ==================== 统计查询 ====================

// 获取统计信息
router.get('/statistics', auth(['admin']), async (req, res) => {
  try {
    const studentStats = await pool.query(`
      SELECT 
        s.student_id,
        s.name,
        s.class_name,
        s.major,
        COUNT(e.id) AS course_count,
        ROUND(COALESCE(AVG(e.score), 0), 1) AS avg_score,
        MAX(e.score) AS max_score,
        MIN(e.score) AS min_score
      FROM student s
      LEFT JOIN enrollment e ON s.student_id = e.student_id
      GROUP BY s.student_id, s.name, s.class_name, s.major
      ORDER BY s.student_id
    `);
    
    const courseStats = await pool.query(`
      SELECT 
        c.course_id,
        c.course_name,
        c.semester,
        c.teacher_id,
        c.teacher_name,
        c.credit,
        COUNT(e.id) AS student_count,
        ROUND(COALESCE(AVG(e.score), 0), 1) AS avg_score,
        MAX(e.score) AS max_score,
        MIN(e.score) AS min_score
      FROM course c
      LEFT JOIN enrollment e ON c.course_id = e.course_id
      GROUP BY c.course_id, c.course_name, c.semester, c.teacher_id, c.teacher_name, c.credit
      ORDER BY c.semester DESC, c.course_id
    `);

    const teacherStats = await pool.query(`
      SELECT 
        t.teacher_id,
        t.name AS teacher_name,
        COUNT(DISTINCT c.course_id) AS course_count,
        COUNT(e.id) AS enrollment_count,
        ROUND(COALESCE(AVG(e.score), 0), 1) AS avg_score,
        ROUND(
          COALESCE(
            SUM(CASE WHEN e.score >= 60 THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(e.score), 0),
            0
          ),
          1
        ) AS pass_rate
      FROM teacher t
      LEFT JOIN course c ON t.teacher_id = c.teacher_id
      LEFT JOIN enrollment e ON c.course_id = e.course_id
      GROUP BY t.teacher_id, t.name
      ORDER BY t.teacher_id
    `);
    
    ok(res, { 
      studentStats: studentStats[0],
      courseStats: courseStats[0],
      teacherStats: teacherStats[0]
    });
  } catch (error) {
    console.error('获取统计信息错误:', error);
    fail(res, '获取统计信息失败', 500);
  }
});

export { router };
