import crypto from 'crypto';

const DEFAULT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');
const DEFAULT_EXPIRES_IN_SECONDS = Number(process.env.JWT_EXPIRES_IN_SECONDS || 8 * 60 * 60);

const encodeJson = (value) => Buffer.from(JSON.stringify(value)).toString('base64url');

const decodeJson = (value) => {
  try {
    return JSON.parse(Buffer.from(value, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
};

const sign = (data, secret) => {
  return crypto.createHmac('sha256', secret).update(data).digest('base64url');
};

export const createToken = (payload, options = {}) => {
  const secret = options.secret || DEFAULT_SECRET;
  const expiresInSeconds = options.expiresInSeconds ?? DEFAULT_EXPIRES_IN_SECONDS;
  const now = Math.floor(Date.now() / 1000);

  const header = { alg: 'HS256', typ: 'JWT' };
  const finalPayload = {
    ...payload,
    iat: now,
    exp: now + expiresInSeconds,
  };

  const encodedHeader = encodeJson(header);
  const encodedPayload = encodeJson(finalPayload);
  const data = `${encodedHeader}.${encodedPayload}`;
  const signature = sign(data, secret);

  return `${data}.${signature}`;
};

export const verifyToken = (token, options = {}) => {
  if (!token) {
    throw new Error('TOKEN_MISSING');
  }

  const secret = options.secret || DEFAULT_SECRET;
  const parts = token.split('.');

  if (parts.length !== 3) {
    throw new Error('TOKEN_INVALID');
  }

  const [encodedHeader, encodedPayload, signature] = parts;
  const header = decodeJson(encodedHeader);
  const payload = decodeJson(encodedPayload);

  if (!header || !payload) {
    throw new Error('TOKEN_INVALID');
  }

  if (header.alg !== 'HS256' || header.typ !== 'JWT') {
    throw new Error('TOKEN_INVALID');
  }

  const expectedSignature = sign(`${encodedHeader}.${encodedPayload}`, secret);
  const expectedBuffer = Buffer.from(expectedSignature, 'base64url');
  const actualBuffer = Buffer.from(signature, 'base64url');

  if (
    expectedBuffer.length !== actualBuffer.length ||
    !crypto.timingSafeEqual(expectedBuffer, actualBuffer)
  ) {
    throw new Error('TOKEN_INVALID');
  }

  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) {
    throw new Error('TOKEN_EXPIRED');
  }

  return payload;
};
