-- 学生选课成绩管理系统 - GaussDB/openGauss 初始化脚本
-- 说明：请先在华为云 GaussDB/openGauss 控制台创建目标 database，再在该 database 中执行本脚本。

SET search_path TO public;

CREATE TABLE IF NOT EXISTS admin (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL DEFAULT '123456',
  name VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS student (
  student_id VARCHAR(20) PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  gender VARCHAR(8) NOT NULL CHECK (gender IN ('男', '女')),
  age SMALLINT,
  class_name VARCHAR(50) NOT NULL,
  major VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  password VARCHAR(50) NOT NULL DEFAULT '123456',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS teacher (
  teacher_id VARCHAR(20) PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  gender VARCHAR(8) CHECK (gender IN ('男', '女')),
  title VARCHAR(50),
  department VARCHAR(100),
  phone VARCHAR(20),
  password VARCHAR(50) NOT NULL DEFAULT '123456',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS course (
  course_id VARCHAR(20) PRIMARY KEY,
  course_name VARCHAR(100) NOT NULL,
  credit NUMERIC(3,1) NOT NULL DEFAULT 0,
  teacher_id VARCHAR(20) NOT NULL,
  teacher_name VARCHAR(50) NOT NULL,
  semester VARCHAR(20) NOT NULL DEFAULT '2025-2026-2',
  selected_count INTEGER NOT NULL DEFAULT 0,
  max_students INTEGER NOT NULL DEFAULT 50,
  classroom VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_course_teacher FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id) ON DELETE RESTRICT ON UPDATE CASCADE
);

ALTER TABLE student ALTER COLUMN gender TYPE VARCHAR(8);
ALTER TABLE teacher ALTER COLUMN gender TYPE VARCHAR(8);

CREATE TABLE IF NOT EXISTS enrollment (
  id SERIAL PRIMARY KEY,
  student_id VARCHAR(20) NOT NULL,
  course_id VARCHAR(20) NOT NULL,
  semester VARCHAR(20) NOT NULL DEFAULT '2025-2026-2',
  select_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  score NUMERIC(5,1) DEFAULT NULL,
  CONSTRAINT fk_enrollment_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_enrollment_course FOREIGN KEY (course_id) REFERENCES course(course_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT uk_enrollment UNIQUE (student_id, course_id)
);

CREATE TABLE IF NOT EXISTS teaching_log (
  id SERIAL PRIMARY KEY,
  teacher_id VARCHAR(20) NOT NULL,
  course_id VARCHAR(20) NOT NULL,
  teaching_date DATE NOT NULL,
  topic VARCHAR(100) NOT NULL,
  content TEXT,
  homework TEXT,
  remark TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uk_teaching_log UNIQUE (teacher_id, course_id, teaching_date, topic),
  CONSTRAINT fk_log_teacher FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_log_course FOREIGN KEY (course_id) REFERENCES course(course_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE OR REPLACE FUNCTION fn_enrollment_after_insert()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE course
  SET selected_count = COALESCE(selected_count, 0) + 1
  WHERE course_id = NEW.course_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION fn_enrollment_after_delete()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE course
  SET selected_count = GREATEST(COALESCE(selected_count, 0) - 1, 0)
  WHERE course_id = OLD.course_id;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION fn_touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_enrollment_after_insert ON enrollment;
CREATE TRIGGER trg_enrollment_after_insert
AFTER INSERT ON enrollment
FOR EACH ROW
EXECUTE PROCEDURE fn_enrollment_after_insert();

DROP TRIGGER IF EXISTS trg_enrollment_after_delete ON enrollment;
CREATE TRIGGER trg_enrollment_after_delete
AFTER DELETE ON enrollment
FOR EACH ROW
EXECUTE PROCEDURE fn_enrollment_after_delete();

DROP TRIGGER IF EXISTS trg_teaching_log_touch ON teaching_log;
CREATE TRIGGER trg_teaching_log_touch
BEFORE UPDATE ON teaching_log
FOR EACH ROW
EXECUTE PROCEDURE fn_touch_updated_at();

-- 存储过程定义见 database/sp-select-course.sql，由 full-init.sh 单独创建。

INSERT INTO admin (username, password, name)
SELECT 'admin', '123456', '系统管理员'
WHERE NOT EXISTS (
  SELECT 1 FROM admin WHERE username = 'admin'
);

INSERT INTO student (student_id, name, gender, age, class_name, major, phone, password)
SELECT v.student_id, v.name, v.gender, v.age, v.class_name, v.major, v.phone, v.password
FROM (
  VALUES
    ('2023001', '张明', '男', 20, '计科2301', '计算机科学与技术', '13800000001', '123456'),
    ('2023002', '李华', '女', 19, '软工2301', '软件工程', '13800000002', '123456'),
    ('2023003', '王琳', '女', 20, '网工2301', '网络工程', '13800000003', '123456'),
    ('2023004', '赵强', '男', 21, '计科2302', '计算机科学与技术', '13800000004', '123456')
) AS v(student_id, name, gender, age, class_name, major, phone, password)
WHERE NOT EXISTS (
  SELECT 1 FROM student s WHERE s.student_id = v.student_id
);

INSERT INTO teacher (teacher_id, name, gender, title, department, phone, password)
SELECT v.teacher_id, v.name, v.gender, v.title, v.department, v.phone, v.password
FROM (
  VALUES
    ('T001', '刘老师', '男', '副教授', '计算机学院', '13900000001', '123456'),
    ('T002', '陈老师', '女', '讲师', '计算机学院', '13900000002', '123456'),
    ('T003', '周老师', '男', '教授', '软件学院', '13900000003', '123456')
) AS v(teacher_id, name, gender, title, department, phone, password)
WHERE NOT EXISTS (
  SELECT 1 FROM teacher t WHERE t.teacher_id = v.teacher_id
);

INSERT INTO course (
  course_id,
  course_name,
  credit,
  teacher_id,
  teacher_name,
  semester,
  selected_count,
  max_students,
  classroom
)
SELECT v.course_id, v.course_name, v.credit, v.teacher_id, v.teacher_name, v.semester, v.selected_count, v.max_students, v.classroom
FROM (
  VALUES
    ('C001', '数据库原理', 4.0, 'T001', '刘老师', '2025-2026-2', 0, 60, 'A201'),
    ('C002', '数据结构', 3.5, 'T002', '陈老师', '2025-2026-2', 0, 50, 'B302'),
    ('C003', '操作系统', 4.0, 'T003', '周老师', '2025-2026-2', 0, 45, 'C105'),
    ('C004', '高等数学', 3.0, 'T001', '刘老师', '2024-2025-2', 0, 80, 'D401')
) AS v(course_id, course_name, credit, teacher_id, teacher_name, semester, selected_count, max_students, classroom)
WHERE NOT EXISTS (
  SELECT 1 FROM course c WHERE c.course_id = v.course_id
);

INSERT INTO enrollment (student_id, course_id, semester, score)
SELECT v.student_id, v.course_id, v.semester, v.score
FROM (
  VALUES
    ('2023001', 'C001', '2025-2026-2', 86.0),
    ('2023001', 'C002', '2025-2026-2', 91.0),
    ('2023002', 'C001', '2025-2026-2', 88.0),
    ('2023003', 'C003', '2025-2026-2', 79.0),
    ('2023004', 'C001', '2025-2026-2', NULL),
    ('2023004', 'C002', '2025-2026-2', NULL),
    ('2023001', 'C004', '2024-2025-2', 95.0)
) AS v(student_id, course_id, semester, score)
WHERE NOT EXISTS (
  SELECT 1 FROM enrollment e WHERE e.student_id = v.student_id AND e.course_id = v.course_id
);

INSERT INTO teaching_log (teacher_id, course_id, teaching_date, topic, content, homework, remark)
SELECT v.teacher_id, v.course_id, v.teaching_date, v.topic, v.content, v.homework, v.remark
FROM (
  VALUES
    ('T001', 'C001', DATE '2026-03-04', '关系模型与完整性约束', '讲解关系模型、主键、外键和实体完整性。', '完成教材第 2 章课后题 1-4。', '课堂提问反馈良好。'),
    ('T001', 'C001', DATE '2026-03-11', 'SQL 查询基础', '演示 SELECT、JOIN、GROUP BY 的常见用法。', '完成 School 数据库查询练习。', '下节课安排上机。'),
    ('T002', 'C002', DATE '2026-03-06', '线性表与顺序存储', '介绍线性表基本操作和顺序表实现。', '编写顺序表插入与删除函数。', ''),
    ('T003', 'C003', DATE '2026-03-08', '进程管理概述', '讲解进程状态、进程控制块和调度目标。', '预习进程调度算法。', '')
) AS v(teacher_id, course_id, teaching_date, topic, content, homework, remark)
WHERE NOT EXISTS (
  SELECT 1
  FROM teaching_log l
  WHERE l.teacher_id = v.teacher_id
    AND l.course_id = v.course_id
    AND l.teaching_date = v.teaching_date
    AND l.topic = v.topic
);

UPDATE course c
SET selected_count = (
  SELECT COUNT(*)
  FROM enrollment e
  WHERE e.course_id = c.course_id
);

SELECT 'GaussDB/openGauss 数据库初始化完成' AS status;
