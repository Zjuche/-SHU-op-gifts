DROP PROCEDURE IF EXISTS sp_select_course(VARCHAR, VARCHAR);
DROP PROCEDURE IF EXISTS sp_select_course(TEXT, TEXT);

CREATE OR REPLACE PROCEDURE sp_select_course(
  IN p_student_id TEXT,
  IN p_course_id TEXT
)
AS
DECLARE
  v_student_exists INTEGER := 0;
  v_course_exists INTEGER := 0;
  v_duplicate INTEGER := 0;
  v_selected_count INTEGER := 0;
  v_max_students INTEGER := 0;
  v_course_semester VARCHAR(20) := '';
BEGIN
  SELECT COUNT(*) INTO v_student_exists
  FROM student
  WHERE student_id = p_student_id;

  IF v_student_exists = 0 THEN
    RAISE EXCEPTION '学生不存在';
  END IF;

  SELECT COUNT(*) INTO v_course_exists
  FROM course
  WHERE course_id = p_course_id;

  IF v_course_exists = 0 THEN
    RAISE EXCEPTION '课程不存在';
  END IF;

  SELECT COUNT(*) INTO v_duplicate
  FROM enrollment
  WHERE student_id = p_student_id AND course_id = p_course_id;

  IF v_duplicate > 0 THEN
    RAISE EXCEPTION '该学生已选择此课程';
  END IF;

  SELECT semester, COALESCE(selected_count, 0), max_students
  INTO v_course_semester, v_selected_count, v_max_students
  FROM course
  WHERE course_id = p_course_id
  FOR UPDATE;

  IF v_selected_count >= v_max_students THEN
    RAISE EXCEPTION '课程人数已满';
  END IF;

  INSERT INTO enrollment (student_id, course_id, semester, select_time, score)
  VALUES (p_student_id, p_course_id, v_course_semester, CURRENT_TIMESTAMP, NULL);
END;
/
