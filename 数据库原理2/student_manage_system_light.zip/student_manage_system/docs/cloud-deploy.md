# 云服务器部署说明

## 推荐部署结构

- openGauss：Docker 容器运行，数据库端口只对后端或自己的管理 IP 开放。
- 后端：Node.js 运行在 `3000`，读取 `backend/.env`。
- 前端：`npm run build` 后由 Nginx 托管 `frontend/dist`。
- Nginx：静态文件走 `/`，接口 `/api` 反向代理到 `127.0.0.1:3000`。

这种结构下，前端代码不用写服务器 IP，默认请求同源 `/api`，换服务器也不用改程序。

## 1. 安装基础环境

```bash
sudo apt update
sudo apt install -y git curl nginx postgresql-client
curl -fsSL https://get.docker.com | bash
sudo usermod -aG docker $USER
```

重新登录服务器，让 Docker 用户组生效。

## 2. 拉取项目并安装依赖

```bash
git clone <你的仓库地址> student_manage_system
cd student_manage_system

cd backend && npm ci
cd ../frontend && npm ci
cd ..
```

如果服务器没有 Node.js，建议安装 Node.js 22 LTS 或更高版本。

## 3. 启动 openGauss

生产环境请先设置强密码：

```bash
export OPENGAUSS_PASSWORD='换成强密码'
export OPENGAUSS_USER='student_user'
export OPENGAUSS_HOST_PORT='5432'
docker compose -f docker-compose.opengauss.yml up -d
```

第一次创建项目库：

```bash
PGPASSWORD="$OPENGAUSS_PASSWORD" psql -h 127.0.0.1 -p "$OPENGAUSS_HOST_PORT" -U gaussdb -d postgres \
  -c "CREATE DATABASE school OWNER student_user;"
```

## 4. 配置后端

```bash
cp backend/.env.example backend/.env
```

`backend/.env` 示例：

```env
PORT=3000
DB_HOST=127.0.0.1
DB_PORT=5432
DB_USER=student_user
DB_PASSWORD=换成强密码
DB_NAME=school
DB_SSL=disable
DB_SSL_REJECT_UNAUTHORIZED=false
JWT_SECRET=换成随机长字符串
```

初始化数据库：

```bash
bash full-init.sh
```

## 5. 启动后端

演示部署可以直接：

```bash
cd backend
npm start
```

长期运行建议用 PM2：

```bash
npm install -g pm2
cd backend
pm2 start src/app.js --name student-manage-backend
pm2 save
pm2 startup
```

## 6. 构建前端

默认前端请求 `/api`，适合 Nginx 同源反向代理：

```bash
cd frontend
npm run build
```

如果不用 Nginx 反代，而是前端直连后端，则构建前设置：

```bash
VITE_API_BASE_URL=http://你的服务器IP:3000/api npm run build
```

## 7. 配置 Nginx

示例配置：

```nginx
server {
    listen 80;
    server_name _;

    root /path/to/student_manage_system/frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:3000/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

启用后重载：

```bash
sudo nginx -t
sudo systemctl reload nginx
```

## 8. 安全组建议

- 开放 `80` 或 `443` 给公网访问。
- `3000` 不建议公网开放，交给 Nginx 反代。
- `5432` 不建议公网开放。如果必须远程管理，只允许自己的 IP。

## 9. 验证

```bash
curl http://127.0.0.1:3000/
curl http://服务器IP/api/statistics
```

浏览器访问：

```text
http://服务器IP
```
