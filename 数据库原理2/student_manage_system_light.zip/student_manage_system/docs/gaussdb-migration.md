# GaussDB/openGauss 迁移说明

## 迁移目标

项目数据库由本地 MySQL 迁移为华为云 GaussDB/openGauss，满足课程“鼓励使用国产数据库、尤其是华为 openGauss 或 GaussDB”的要求。

## 已完成改动

- 后端数据库驱动：`mysql2` -> `pg`
- 默认端口：`3306` -> `5432`
- 初始化脚本：`mysql` 命令 -> `gsql`/`psql`
- 建库脚本：MySQL 方言 -> GaussDB/openGauss 方言
- 存储过程：MySQL `CREATE PROCEDURE ... BEGIN` -> PL/pgSQL
- 触发器：MySQL trigger -> openGauss trigger function + trigger
- 文档：补充华为数据库自学报告与迁移说明

## 云端准备

1. 在华为云创建 GaussDB/openGauss 实例。
2. 创建目标 database，建议命名为 `school`。
3. 创建应用账号，建议命名为 `student_user`。
4. 配置安全组，允许当前开发机或部署服务器访问数据库端口。
5. 获取连接信息：

   - `DB_HOST`
   - `DB_PORT`
   - `DB_NAME`
   - `DB_USER`
   - `DB_PASSWORD`
   - `DB_SSL`

## 后端环境变量

复制模板：

```bash
cp backend/.env.example backend/.env
```

填写示例：

```env
PORT=3000
DB_HOST=your-gaussdb-host
DB_PORT=5432
DB_USER=student_user
DB_PASSWORD=your-password
DB_NAME=school
DB_SSL=disable
DB_SSL_REJECT_UNAUTHORIZED=false
JWT_SECRET=your-random-jwt-secret
```

如果使用公网或云数据库要求 SSL，请按实例要求将 `DB_SSL` 改为 `require`，并根据证书校验情况调整 `DB_SSL_REJECT_UNAUTHORIZED`。

## 初始化数据库

安装 `gsql` 或 `psql` 后执行：

```bash
bash full-init.sh
```

如果没有命令行客户端，也可以在华为云 DAS 中打开目标 database，手动执行：

```text
database/schema-final.sql
database/sp-select-course.sql
```

本地 Docker 实践步骤见 `docs/local-opengauss-practice.md`。

## 启动项目

```bash
./launch.sh
```

或手动启动：

```bash
cd backend
npm run dev

cd frontend
npm run dev
```

## 迁移后的数据库对象

表：

- `admin`
- `student`
- `teacher`
- `course`
- `enrollment`
- `teaching_log`

触发器：

- `trg_enrollment_after_insert`
- `trg_enrollment_after_delete`
- `trg_teaching_log_touch`

存储过程：

- `sp_select_course`

## 主要 SQL 方言替换

| MySQL | GaussDB/openGauss |
| --- | --- |
| `AUTO_INCREMENT` | `SERIAL` |
| `DATETIME` | `TIMESTAMP` |
| `TINYINT` | `SMALLINT` |
| `ENUM` | `VARCHAR + CHECK` |
| `INSERT IGNORE` | `INSERT ... SELECT ... WHERE NOT EXISTS` |
| `DATE_FORMAT()` | `to_char()` |
| `FIELD()` | `CASE ... WHEN ... END` |

## 验证建议

1. 执行 `bash full-init.sh`，确认 6 张表、触发器、存储过程均存在。
2. 登录管理员，查看仪表盘和统计查询。
3. 登录学生，执行选课，确认存储过程可用。
4. 查看课程已选人数，确认触发器可自动维护。
5. 登录教师，录入成绩并新增教学日志。
