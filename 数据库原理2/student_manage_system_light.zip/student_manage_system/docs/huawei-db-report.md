# 华为数据库自学报告

## 学习对象

本次自学选择华为云 GaussDB/openGauss。课程要求鼓励使用国产数据库，尤其是华为 openGauss 或 GaussDB，因此项目后续数据库迁移以 GaussDB/openGauss 为目标。

学习入口：

- https://education.huaweicloud.com/courses/course-v1:HuaweiX+CBUCNXK034+Self-paced/about
- https://support.huaweicloud.com/intl/en-us/productdesc-gaussdb/gaussdb_01_891.html
- https://support.huaweicloud.com/eu/centralized-devg-v8-gaussdb/gaussdb-42-1649.html

## 学了哪些内容

1. GaussDB/openGauss 的基本定位

   GaussDB 是华为云提供的企业级关系型数据库服务，支持云端实例管理、备份恢复、监控、安全组访问控制和迁移能力。openGauss 是其重要技术基础之一，语法和使用方式与 PostgreSQL 体系接近。

2. 云端数据库连接方式

   华为云 GaussDB 实例需要先在控制台创建数据库实例，再配置安全组、数据库账号、目标 database。应用通过 host、port、database、user、password 连接。常用工具包括 gsql、DAS、DBeaver、Navicat 等。

3. SQL 方言差异

   原项目使用 MySQL，迁移时需要调整数据类型和语法。例如：

   - `AUTO_INCREMENT` 改为 `SERIAL`
   - `DATETIME` 改为 `TIMESTAMP`
   - `TINYINT` 改为 `SMALLINT`
   - `ENUM` 改为 `VARCHAR + CHECK`
   - `INSERT IGNORE` 改为 `INSERT ... SELECT ... WHERE NOT EXISTS`
   - `DATE_FORMAT()` 改为 `to_char()`

4. 触发器和存储过程

   GaussDB/openGauss 使用 PL/pgSQL 风格定义函数、触发器和存储过程。项目中保留了实验要求的数据库对象：

   - 触发器：维护课程已选人数
   - 存储过程：封装选课规则，包括学生/课程存在性、重复选课、人数上限校验

5. Node.js 后端适配

   原后端使用 `mysql2`，迁移后使用 `pg` 驱动连接 GaussDB/openGauss。后端连接配置统一放在 `backend/.env`，便于更换云数据库实例。

## 掌握了哪些内容

- 能在华为云上理解 GaussDB/openGauss 实例、database、账号、安全组的关系。
- 能将 MySQL 常见建表语法迁移到 openGauss/PostgreSQL 风格。
- 能编写 GaussDB/openGauss 的触发器函数和存储过程。
- 能用 Node.js 后端连接云端数据库，并通过环境变量管理连接信息。
- 能分析数据库迁移中的主要风险：SQL 方言、数据类型、驱动差异、权限与网络连通性。

## 用户体验

GaussDB/openGauss 的优势是云端管理完整，数据库实例创建后可以通过 DAS 或客户端直接执行 SQL，适合课程项目展示“云端数据库”的要求。与本地数据库相比，云数据库更接近实际业务部署环境。

项目迁移后，前端体验没有变化，用户仍然通过浏览器完成登录、选课、录成绩和统计查询。变化主要发生在后端和数据库层：数据不再依赖本机数据库，而是持久化到云端 GaussDB/openGauss。

## 自己感觉的优缺点

优点：

- 国产数据库，符合课程鼓励方向。
- 云端部署后更方便展示数据持久化和远程访问。
- 支持触发器、存储过程、事务、外键等关系数据库能力。
- 与 PostgreSQL 体系接近，学习资料和迁移经验比较容易复用。

缺点：

- 从 MySQL 迁移需要改不少 SQL 方言。
- 云端实例需要配置安全组、网络和账号权限，新手容易卡在连接问题。
- Node.js 直连 GaussDB/openGauss 的资料不如 Java/JDBC 资料多，需要结合 PostgreSQL 兼容方式处理。
- 免费/学生资源、实例规格和计费需要提前确认，避免产生不必要费用。

## 在项目中的应用

本项目已完成以下迁移工作：

- 后端驱动由 `mysql2` 改为 `pg`
- 初始化脚本改为 GaussDB/openGauss SQL
- 表结构迁移为 openGauss 兼容类型
- 触发器和存储过程改为 PL/pgSQL 风格
- `full-init.sh` 支持用 `gsql` 或 `psql` 初始化云端数据库
- 文档和环境变量模板改为华为云数据库配置

## 总结

通过本次自学，我理解了国产云数据库的基本使用流程，也掌握了从 MySQL 项目迁移到 GaussDB/openGauss 的关键步骤。迁移工作让我体会到数据库不仅是“换一个连接地址”，还涉及 SQL 方言、驱动、数据类型、权限和部署环境的整体适配。
