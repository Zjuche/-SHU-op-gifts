# 本地 openGauss 实践记录

## 目标

先在本机用 Docker 跑通 openGauss，验证项目已经脱离 MySQL。后续迁移到云服务器时，只需要把同样的 openGauss 容器和项目配置搬到云端。

## 启动 openGauss

本机 5432 端口已被占用，因此 openGauss 映射到 15432：

```bash
OPENGAUSS_PASSWORD='请替换为数据库强密码' docker compose -f docker-compose.opengauss.yml up -d
```

也可以通过环境变量调整本机映射端口和密码：

```bash
OPENGAUSS_HOST_PORT=15432 OPENGAUSS_PASSWORD='请替换为数据库强密码' docker compose -f docker-compose.opengauss.yml up -d
```

如果已经手动创建过同名容器，可以先停止并删除：

```bash
docker rm -f student-opengauss
```

## 创建项目数据库

容器会创建 `student_user`，但该用户不是建库管理员。第一次需要用 `gaussdb` 创建 `school`：

```bash
PGPASSWORD='请替换为数据库强密码' psql -h 127.0.0.1 -p 15432 -U gaussdb -d postgres \
  -c "CREATE DATABASE school OWNER student_user;"
```

## 后端配置

`backend/.env` 本地实践配置：

```env
PORT=3000
DB_HOST=127.0.0.1
DB_PORT=15432
DB_USER=student_user
DB_PASSWORD=请替换为数据库强密码
DB_NAME=school
DB_SSL=disable
DB_SSL_REJECT_UNAUTHORIZED=false
JWT_SECRET=your-random-jwt-secret
```

## 初始化项目数据

```bash
bash full-init.sh
```

初始化内容：

- 6 张核心表
- 3 个触发器
- 1 个存储过程：`sp_select_course`
- 演示账号和教学数据

## 验证命令

```bash
PGPASSWORD='请替换为数据库强密码' psql -h 127.0.0.1 -p 15432 -U student_user -d school \
  -c "SELECT proname, proargtypes::regtype[] FROM pg_proc WHERE proname='sp_select_course';"
```

```bash
PGPASSWORD='请替换为数据库强密码' psql -h 127.0.0.1 -p 15432 -U student_user -d school \
  -c "SELECT trigger_name FROM information_schema.triggers WHERE trigger_schema='public' ORDER BY trigger_name;"
```

## 迁移到云服务器

云服务器部署时可以沿用同一个 compose 文件。区别主要是：

- 云服务器安全组开放应用端口，数据库端口只对后端服务器或自己的 IP 开放。
- `backend/.env` 的 `DB_HOST` 改成云服务器内网地址或公网地址。
- 生产环境请更换 `GS_PASSWORD` 和 `DB_PASSWORD`。
