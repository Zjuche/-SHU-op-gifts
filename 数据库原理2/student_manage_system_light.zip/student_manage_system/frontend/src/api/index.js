import axios from 'axios';
import { useAuthStore } from '@/stores/auth';
import router from '@/router';

// 创建 axios 实例
const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// 请求拦截器 - 添加 token
api.interceptors.request.use(
  (config) => {
    const authStore = useAuthStore();
    if (authStore.token) {
      config.headers.Authorization = `Bearer ${authStore.token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// 响应拦截器 - 处理错误
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // 401 错误 - 未授权，重定向到登录页
    if (error.response?.status === 401) {
      const authStore = useAuthStore();
      authStore.logout();
      router.push('/login');
    }
    return Promise.reject(error);
  }
);

// API 方法
export default {
  // 登录
  post: (url, data) => api.post(url, data),
  
  // 获取
  get: (url, params) => api.get(url, { params }),
  
  // 更新
  put: (url, data) => api.put(url, data),
  
  // 删除
  delete: (url) => api.delete(url),
  
  // POST 文件上传
  postForm: (url, data) => api.post(url, data, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
};

// 导出各个接口
export const authApi = {
  login: (username, password) => api.post('/login', { username, password })
};

export const studentApi = {
  list: (params) => api.get('/students', { params }),
  create: (data) => api.post('/students', data),
  update: (id, data) => api.put(`/students/${id}`, data),
  delete: (id) => api.delete(`/students/${id}`)
};

export const courseApi = {
  list: (params) => api.get('/courses', { params }),
  create: (data) => api.post('/courses', data),
  update: (id, data) => api.put(`/courses/${id}`, data),
  delete: (id) => api.delete(`/courses/${id}`)
};

export const enrollmentApi = {
  list: (params) => api.get('/enrollments', { params }),
  create: (data) => api.post('/enrollments', data),
  delete: (id) => api.delete(`/enrollments/${id}`),
  updateGrade: (id, score) => api.put(`/enrollments/${id}/score`, { score })
};

export const statisticsApi = {
  get: () => api.get('/statistics'),
  student: () => api.get('/student/statistics'),
  teacher: () => api.get('/teacher/statistics')
};

export const teacherApi = {
  list: (params) => api.get('/teachers', { params }),
  create: (data) => api.post('/teachers', data),
  update: (id, data) => api.put(`/teachers/${id}`, data),
  delete: (id) => api.delete(`/teachers/${id}`)
};

export const teachingLogApi = {
  list: (params) => api.get('/teaching-logs', { params }),
  create: (data) => api.post('/teaching-logs', data),
  update: (id, data) => api.put(`/teaching-logs/${id}`, data),
  delete: (id) => api.delete(`/teaching-logs/${id}`)
};
