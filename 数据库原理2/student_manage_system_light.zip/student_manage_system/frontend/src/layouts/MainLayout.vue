<script setup>
import { computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useSystemStore } from '../stores/system'

const route = useRoute()
const router = useRouter()
const store = useSystemStore()

const menus = [
  { path: '/dashboard', label: '系统首页' },
  { path: '/students', label: '学生管理' },
  { path: '/courses', label: '课程管理' },
  { path: '/enrollments', label: '选课管理' },
  { path: '/drops', label: '退课管理' },
  { path: '/scores', label: '成绩管理' },
  { path: '/statistics', label: '统计查询' }
]

const activePath = computed(() => route.path)

const handleSelect = (path) => {
  router.push(path)
}

onMounted(() => {
  store.initialize()
})
</script>

<template>
  <div class="layout-shell">
    <header class="top-header">
      <div class="system-name">学生选课成绩管理系统</div>
      <div class="header-right">管理员：admin　|　当前模块：{{ menus.find(item => item.path === activePath)?.label || '系统首页' }}</div>
    </header>

    <div class="body-shell">
      <aside class="sidebar">
        <div class="sidebar-title">功能菜单</div>
        <div
          v-for="item in menus"
          :key="item.path"
          class="menu-item"
          :class="{ active: activePath === item.path }"
          @click="handleSelect(item.path)"
        >
          {{ item.label }}
        </div>
      </aside>

      <main class="content-area">
        <router-view />
      </main>
    </div>
  </div>
</template>

<style scoped>
.layout-shell {
  min-height: 100vh;
  background: var(--bg-page);
}

.top-header {
  height: 56px;
  background: linear-gradient(to bottom, #dcd6c7, #c9c1b2);
  border-bottom: 1px solid var(--border-color);
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 16px;
}

.system-name {
  font-size: 20px;
  font-weight: 700;
  color: #3d382f;
  letter-spacing: 1px;
}

.header-right {
  font-size: 13px;
  color: var(--text-sub);
}

.body-shell {
  display: flex;
  min-height: calc(100vh - 56px);
}

.sidebar {
  width: 190px;
  background: var(--bg-sidebar);
  border-right: 1px solid var(--border-color);
  padding: 12px 10px;
}

.sidebar-title {
  background: #d4ccbc;
  border: 1px solid var(--border-color);
  padding: 8px 10px;
  font-weight: 700;
  margin-bottom: 8px;
}

.menu-item {
  padding: 10px 12px;
  border: 1px solid var(--border-color);
  background: #f1ece2;
  margin-bottom: 6px;
  cursor: pointer;
  user-select: none;
}

.menu-item.active {
  background: #d9d1c1;
  color: #2b2822;
  font-weight: 700;
}

.content-area {
  flex: 1;
  padding: 12px;
}
</style>
