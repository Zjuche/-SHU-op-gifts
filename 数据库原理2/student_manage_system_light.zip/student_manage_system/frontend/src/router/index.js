import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import { ElMessage } from 'element-plus';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      redirect: '/login'
    },
    {
      path: '/login',
      name: 'Login',
      component: () => import('@/views/Login.vue'),
      meta: { requiresAuth: false }
    },
    // ==================== 管理员路由 ====================
    {
      path: '/admin',
      component: () => import('@/views/admin/Layout.vue'),
      meta: { requiresAuth: true, role: 'admin' },
      children: [
        { path: '', redirect: '/admin/dashboard' },
        { path: 'dashboard', name: 'AdminDashboard', component: () => import('@/views/admin/Dashboard.vue') },
        { path: 'student', name: 'AdminStudent', component: () => import('@/views/admin/StudentManage.vue') },
        { path: 'teacher', name: 'AdminTeacher', component: () => import('@/views/admin/TeacherManage.vue') },
        { path: 'course', name: 'AdminCourse', component: () => import('@/views/admin/CourseManage.vue') },
        { path: 'select', name: 'AdminEnroll', component: () => import('@/views/admin/EnrollManage.vue') },
        { path: 'drop', name: 'AdminDrop', component: () => import('@/views/admin/DropManage.vue') },
        { path: 'grade', name: 'AdminGrade', component: () => import('@/views/admin/GradeManage.vue') },
        { path: 'statistics', name: 'AdminStats', component: () => import('@/views/admin/StatisticsView.vue') },
      ]
    },
    // ==================== 学生路由 ====================
    {
      path: '/student',
      component: () => import('@/views/student/Layout.vue'),
      meta: { requiresAuth: true, role: 'student' },
      children: [
        { path: '', redirect: '/student/home' },
        { path: 'home', name: 'StudentHome', component: () => import('@/views/student/Home.vue') },
        { path: 'select-course', name: 'StudentSelect', component: () => import('@/views/student/SelectCourse.vue') },
        { path: 'drop-course', name: 'StudentDrop', component: () => import('@/views/student/DropCourse.vue') },
        { path: 'my-grade', name: 'StudentGrade', component: () => import('@/views/student/MyGrade.vue') },
        { path: 'statistics', name: 'StudentStats', component: () => import('@/views/student/Statistics.vue') },
      ]
    },
    // ==================== 教师路由 ====================
    {
      path: '/teacher',
      component: () => import('@/views/teacher/Layout.vue'),
      meta: { requiresAuth: true, role: 'teacher' },
      children: [
        { path: '', redirect: '/teacher/home' },
        { path: 'home', name: 'TeacherHome', component: () => import('@/views/teacher/Home.vue') },
        { path: 'grade-entry', name: 'TeacherGrade', component: () => import('@/views/teacher/GradeEntry.vue') },
        { path: 'course-list', name: 'TeacherCourses', component: () => import('@/views/teacher/CourseList.vue') },
        { path: 'teaching-log', name: 'TeacherLog', component: () => import('@/views/teacher/TeachingLog.vue') },
        { path: 'statistics', name: 'TeacherStats', component: () => import('@/views/teacher/Statistics.vue') },
      ]
    },
    // 404
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: () => import('@/views/NotFound.vue')
    }
  ]
});

// 路由守卫
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore();

  if (!to.meta.requiresAuth) {
    next();
    return;
  }

  if (!authStore.isLoggedIn) {
    ElMessage.warning('请先登录');
    next('/login');
    return;
  }

  // 检查角色权限（检查当前路由或其父路由的 meta.role）
  const requiredRole = to.meta.role || to.matched.find(r => r.meta.role)?.meta.role;
  if (requiredRole && authStore.role !== requiredRole) {
    ElMessage.error('无权限访问此页面');
    next('/');
    return;
  }

  next();
});

export default router;
