import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    name: 'Simple',
    component: () => import('../views/Simple.vue')
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
