import { defineStore } from 'pinia';
import api from '@/api';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('token') || '',
    user: JSON.parse(localStorage.getItem('user') || 'null'),
    role: localStorage.getItem('role') || '', // 'admin', 'student', 'teacher'
  }),
  
  getters: {
    isLoggedIn: (state) => !!state.token,
    isAdmin: (state) => state.role === 'admin',
    isStudent: (state) => state.role === 'student',
    isTeacher: (state) => state.role === 'teacher',
  },
  
  actions: {
    async login(username, password) {
      try {
        const response = await api.post('/login', { username, password });
        const { role, name, token, ...userInfo } = response.data.data;
        
        // 保存用户信息
        this.token = token;
        this.role = role;
        this.user = { name, ...userInfo };
        
        // 持久化存储
        localStorage.setItem('token', token);
        localStorage.setItem('role', role);
        localStorage.setItem('user', JSON.stringify({ name, ...userInfo }));
        
        return { success: true };
      } catch (error) {
        console.error('登录失败:', error);
        return { 
          success: false, 
          message: error.response?.data?.message || '登录失败，请检查用户名和密码' 
        };
      }
    },
    
    logout() {
      this.token = '';
      this.user = null;
      this.role = '';
      localStorage.removeItem('token');
      localStorage.removeItem('role');
      localStorage.removeItem('user');
    },
    
    initAuth() {
      // 初始化时检查本地存储
      const token = localStorage.getItem('token');
      const role = localStorage.getItem('role');
      const userStr = localStorage.getItem('user');
      
      if (token) {
        this.token = token;
      }
      if (role) {
        this.role = role;
      }
      if (userStr) {
        this.user = JSON.parse(userStr);
      }
    }
  }
});
