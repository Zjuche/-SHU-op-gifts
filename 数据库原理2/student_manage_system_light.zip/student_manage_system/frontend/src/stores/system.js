import { defineStore } from 'pinia'
import { api } from '../api'

export const useSystemStore = defineStore('system', {
  state: () => ({
    currentUser: '系统管理员',
    dashboard: {
      studentCount: 0,
      courseCount: 0,
      enrollmentCount: 0,
      scoreCount: 0,
      averageScore: '0.0'
    },
    students: [],
    courses: [],
    enrollments: [],
    statistics: {
      studentStats: [],
      courseStats: []
    }
  }),
  actions: {
    async login(payload) {
      const data = await api.login(payload)
      this.currentUser = data.name
      return data
    },
    async fetchDashboard() {
      this.dashboard = await api.getDashboard()
    },
    async fetchStudents() {
      this.students = await api.getStudents()
    },
    async addStudent(student) {
      await api.createStudent(student)
      await this.fetchStudents()
      await this.fetchDashboard()
    },
    async fetchCourses() {
      this.courses = await api.getCourses()
    },
    async addCourse(course) {
      await api.createCourse(course)
      await this.fetchCourses()
      await this.fetchDashboard()
    },
    async fetchEnrollments(studentId = '') {
      this.enrollments = await api.getEnrollments(studentId)
    },
    async addEnrollment(payload) {
      const result = await api.createEnrollment(payload)
      await this.fetchEnrollments()
      await this.fetchDashboard()
      await this.fetchStatistics()
      return result
    },
    async dropEnrollment(id) {
      await api.deleteEnrollment(id)
      await this.fetchEnrollments()
      await this.fetchDashboard()
      await this.fetchStatistics()
    },
    async updateScore(id, score) {
      await api.updateScore(id, score)
      await this.fetchEnrollments()
      await this.fetchDashboard()
      await this.fetchStatistics()
    },
    async fetchStatistics() {
      this.statistics = await api.getStatistics()
    },
    async initialize() {
      await Promise.all([
        this.fetchDashboard(),
        this.fetchStudents(),
        this.fetchCourses(),
        this.fetchEnrollments(),
        this.fetchStatistics()
      ])
    }
  }
})
