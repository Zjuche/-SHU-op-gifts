export const getCurrentSemester = (date = new Date()) => {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;

  if (month >= 9) {
    return `${year}-${year + 1}-1`;
  }

  if (month >= 2 && month <= 6) {
    return `${year - 1}-${year}-2`;
  }

  return `${year - 1}-${year}-1`;
};

export const sortSemesterList = (semesters = []) => {
  return [...new Set(semesters.filter(Boolean))].sort((a, b) => b.localeCompare(a));
};
