<template>
  <div class="login-container">
    <div class="login-card">
      <div class="login-header">
        <div class="logo-icon">
          <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
            <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
            <path d="M8 7h8M8 11h6" />
          </svg>
        </div>
        <h1 class="login-title">学生选课成绩管理系统</h1>
        <p class="login-subtitle">Student Course Management System</p>
      </div>

      <div class="role-selector">
        <button
          v-for="r in roles"
          :key="r.value"
          :class="['role-btn', { active: selectedRole === r.value }]"
          @click="selectRole(r.value)"
        >
          <span class="role-icon">{{ r.icon }}</span>
          <span>{{ r.label }}</span>
        </button>
      </div>

      <el-form :model="formData" :rules="rules" ref="loginForm" class="login-form">
        <el-form-item prop="username">
          <el-input
            v-model="formData.username"
            :placeholder="usernamePlaceholder"
            :prefix-icon="User"
            size="large"
            clearable
          />
        </el-form-item>

        <el-form-item prop="password">
          <el-input
            v-model="formData.password"
            type="password"
            placeholder="请输入密码"
            :prefix-icon="Lock"
            size="large"
            show-password
            @keyup.enter="handleLogin"
          />
        </el-form-item>

        <el-form-item>
          <el-button
            type="primary"
            :loading="loading"
            @click="handleLogin"
            size="large"
            class="login-button"
          >
            {{ loading ? '登录中...' : '登  录' }}
          </el-button>
        </el-form-item>
      </el-form>
    </div>

  </div>
</template>

<script setup>
import { reactive, ref, computed } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import { User, Lock } from '@element-plus/icons-vue';
import { ElMessage } from 'element-plus';

const router = useRouter();
const authStore = useAuthStore();

const roles = [
  { value: 'admin', label: '管理员', icon: 'ADM' },
  { value: 'student', label: '学  生', icon: 'STD' },
  { value: 'teacher', label: '教  师', icon: 'TCH' },
];

const selectedRole = ref('admin');
const loading = ref(false);
const loginForm = ref(null);

const formData = reactive({
  username: '',
  password: '',
});

const usernamePlaceholder = computed(() => {
  const map = { admin: '请输入管理员账号', student: '请输入学号', teacher: '请输入教师工号' };
  return map[selectedRole.value];
});

const rules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
};

const selectRole = (role) => {
  selectedRole.value = role;
  formData.username = '';
  formData.password = '';
};

const handleLogin = async () => {
  if (!loginForm.value) return;
  await loginForm.value.validate(async (valid) => {
    if (valid) {
      loading.value = true;
      try {
        const result = await authStore.login(formData.username, formData.password);
        if (result.success) {
          ElMessage.success('登录成功');
          setTimeout(() => {
            const routes = { admin: '/admin/dashboard', student: '/student/home', teacher: '/teacher/home' };
            router.push(routes[authStore.role] || '/admin/dashboard');
          }, 300);
        } else {
          ElMessage.error(result.message || '登录失败');
        }
      } catch (error) {
        ElMessage.error('登录失败，请检查网络连接');
      } finally {
        loading.value = false;
      }
    }
  });
};
</script>

<style scoped>
.login-container {
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: var(--app-bg);
  color: var(--text);
  padding: 18px;
}

.login-card {
  width: min(420px, 100%);
  background: var(--panel-bg);
  border: 1px solid var(--border-control);
  padding: 24px;
  box-shadow: 0 12px 28px var(--shadow);
}

.login-header {
  margin-bottom: 22px;
  padding-bottom: 14px;
  border-bottom: 1px solid var(--border-soft);
}

.logo-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  border: 1px solid var(--border-soft);
  background: var(--panel-bg-alt);
  color: var(--text-strong);
  margin-bottom: 12px;
}

.login-title {
  margin: 0 0 5px;
  color: var(--text-strong);
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 0;
}

.login-subtitle {
  font-size: 12px;
  color: var(--text-muted);
  margin: 0;
  letter-spacing: 0;
}

.role-selector {
  display: flex;
  gap: 8px;
  margin-bottom: 18px;
}

.role-btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  min-height: 34px;
  padding: 6px;
  border: 1px solid var(--border-soft);
  border-radius: 0;
  background: var(--control-bg);
  cursor: pointer;
  font-size: 12px;
  color: var(--text-muted);
}

.role-btn:hover {
  border-color: var(--border-control);
  background: var(--control-hover-bg);
}

.role-btn.active {
  border-color: var(--primary);
  background: var(--primary);
  color: #ffffff;
  font-weight: 700;
}

.role-icon {
  color: inherit;
  font-size: 10px;
  font-weight: 800;
}

.login-form {
  margin-top: 0;
}

.login-button {
  width: 100%;
  border-radius: 0;
  font-size: 13px;
  letter-spacing: 0;
}
</style>
