<template>
  <div class="not-found">
    <el-empty description="页面未找到" />
  </div>
</template>

<style scoped>
.not-found {
  min-height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
