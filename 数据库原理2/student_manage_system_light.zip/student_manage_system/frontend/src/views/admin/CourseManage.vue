<template>
  <div class="page-container">
    <div class="page-header">
      <h3>课程管理</h3>
      <el-button type="primary" @click="showAddDialog = true">添加课程</el-button>
    </div>
    <el-card>
      <el-table :data="list" stripe border style="width:100%">
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" width="160" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column prop="credit" label="学分" width="80" />
        <el-table-column prop="teacher_name" label="任课教师" width="120" />
        <el-table-column label="已选人数" width="90">
          <template #default="{ row }">{{ row.selected_count ?? 0 }}</template>
        </el-table-column>
        <el-table-column prop="max_students" label="最大人数" width="100" />
        <el-table-column prop="classroom" label="教室" width="100" />
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="editRow(row)">编辑</el-button>
            <el-button size="small" type="danger" @click="deleteRow(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
    <el-dialog :title="editingRow ? '编辑课程' : '添加课程'" v-model="showAddDialog" width="500px" @close="resetForm">
      <el-form :model="form" :rules="formRules" ref="formRef" label-width="90px">
        <el-form-item label="课程号" prop="course_id">
          <el-input v-model="form.course_id" :disabled="!!editingRow" placeholder="如 C004" />
        </el-form-item>
        <el-form-item label="课程名" prop="course_name">
          <el-input v-model="form.course_name" />
        </el-form-item>
        <el-form-item label="学期" prop="semester">
          <el-input v-model="form.semester" placeholder="如 2025-2026-2" />
        </el-form-item>
        <el-form-item label="学分">
          <el-input-number v-model="form.credit" :min="0.5" :max="10" :step="0.5" />
        </el-form-item>
        <el-form-item label="任课教师" prop="teacher_id">
          <el-select v-model="form.teacher_id" placeholder="选择教师" @change="onTeacherChange">
            <el-option v-for="t in teachers" :key="t.teacher_id" :label="`${t.name} (${t.teacher_id})`" :value="t.teacher_id" />
          </el-select>
        </el-form-item>
        <el-form-item label="最大人数">
          <el-input-number v-model="form.max_students" :min="1" :max="200" />
        </el-form-item>
        <el-form-item label="教室">
          <el-input v-model="form.classroom" placeholder="如 A201" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage, ElMessageBox } from 'element-plus';
import { getCurrentSemester } from '@/utils/semester';

const list = ref([]);
const teachers = ref([]);
const showAddDialog = ref(false);
const editingRow = ref(null);
const formRef = ref(null);
const form = ref({
  course_id: '',
  course_name: '',
  semester: getCurrentSemester(),
  credit: 3,
  teacher_id: '',
  teacher_name: '',
  max_students: 60,
  classroom: ''
});

const formRules = {
  course_id: [{ required: true, message: '请输入课程号', trigger: 'blur' }],
  course_name: [{ required: true, message: '请输入课程名', trigger: 'blur' }],
  semester: [{ required: true, message: '请输入学期', trigger: 'blur' }],
  teacher_id: [{ required: true, message: '请选择教师', trigger: 'change' }],
};

const loadList = async () => {
  try {
    const res = await api.get('/courses');
    list.value = res.data.data;
  } catch (e) { ElMessage.error('获取课程列表失败'); }
};

const loadTeachers = async () => {
  try {
    const res = await api.get('/teachers');
    teachers.value = res.data.data;
  } catch (e) { console.error(e); }
};

const onTeacherChange = (tid) => {
  const t = teachers.value.find(x => x.teacher_id === tid);
  form.value.teacher_name = t ? t.name : '';
};

const editRow = (row) => {
  editingRow.value = row;
  form.value = { ...row };
  showAddDialog.value = true;
};

const deleteRow = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除课程 ${row.course_name}？`, '确认');
    await api.delete(`/courses/${row.course_id}`);
    ElMessage.success('删除成功');
    loadList();
  } catch (e) { if (e !== 'cancel') ElMessage.error(e.response?.data?.message || '删除失败'); }
};

const resetForm = () => {
  editingRow.value = null;
  form.value = {
    course_id: '',
    course_name: '',
    semester: getCurrentSemester(),
    credit: 3,
    teacher_id: '',
    teacher_name: '',
    max_students: 60,
    classroom: ''
  };
};

const submitForm = async () => {
  if (!formRef.value) return;
  await formRef.value.validate(async (valid) => {
    if (!valid) return;
    try {
      if (editingRow.value) {
        await api.put(`/courses/${form.value.course_id}`, form.value);
        ElMessage.success('修改成功');
      } else {
        await api.post('/courses', form.value);
        ElMessage.success('添加成功');
      }
      showAddDialog.value = false;
      loadList();
    } catch (e) { ElMessage.error(e.response?.data?.message || '操作失败'); }
  });
};

onMounted(() => { loadList(); loadTeachers(); });
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
</style>
