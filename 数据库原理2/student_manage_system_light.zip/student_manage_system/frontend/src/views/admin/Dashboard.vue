<template>
  <div class="dashboard">
    <el-row :gutter="20">
      <el-col :span="4">
        <el-card class="stat-card">
          <div class="stat-value">{{ stats.studentCount }}</div>
          <div class="stat-label">学生总数</div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card">
          <div class="stat-value">{{ stats.teacherCount }}</div>
          <div class="stat-label">教师总数</div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card">
          <div class="stat-value">{{ stats.courseCount }}</div>
          <div class="stat-label">课程总数</div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card">
          <div class="stat-value">{{ stats.semesterCount }}</div>
          <div class="stat-label">学期数</div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card">
          <div class="stat-value">{{ stats.enrollmentCount }}</div>
          <div class="stat-label">选课总数</div>
        </el-card>
      </el-col>
      <el-col :span="4">
        <el-card class="stat-card">
          <div class="stat-value">{{ stats.averageScore }}</div>
          <div class="stat-label">平均分</div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';

const stats = ref({
  studentCount: 0,
  teacherCount: 0,
  courseCount: 0,
  semesterCount: 0,
  enrollmentCount: 0,
  averageScore: '0.0'
});

const loadStats = async () => {
  try {
    const response = await api.get('/dashboard');
    stats.value = response.data.data;
  } catch (error) {
    console.error('获取统计数据失败:', error);
  }
};

onMounted(() => {
  loadStats();
});
</script>

<style scoped>
.dashboard {
  padding: 12px;
}

.stat-card {
  text-align: center;
  margin-bottom: 12px;
  background: var(--panel-bg);
  border: 1px solid var(--border-soft);
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: var(--text-strong);
}

.stat-label {
  margin-top: 8px;
  color: var(--text-muted);
  font-size: 11px;
}
</style>
