<template>
  <div class="page-container">
    <div class="page-header"><h3>退课管理</h3></div>
    <el-card>
      <div class="search-bar">
        <el-select v-model="filterStudent" filterable clearable placeholder="按学生筛选" @change="loadData">
          <el-option v-for="s in students" :key="s.student_id" :label="`${s.name} (${s.student_id})`" :value="s.student_id" />
        </el-select>
      </div>
      <el-table :data="enrollments" stripe border>
        <el-table-column prop="student_id" label="学号" width="110" />
        <el-table-column prop="student_name" label="学生姓名" width="100" />
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column prop="select_time" label="选课时间" width="170" />
        <el-table-column label="成绩" width="80">
          <template #default="{ row }">{{ row.score ?? '未录入' }}</template>
        </el-table-column>
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="danger" @click="handleDrop(row)">退课</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage, ElMessageBox } from 'element-plus';

const enrollments = ref([]);
const students = ref([]);
const filterStudent = ref('');

const loadData = async () => {
  try {
    const params = filterStudent.value ? { student_id: filterStudent.value } : {};
    const [eRes, sRes] = await Promise.all([api.get('/enrollments', params), api.get('/students')]);
    enrollments.value = eRes.data.data;
    students.value = sRes.data.data;
  } catch (e) { ElMessage.error('获取数据失败'); }
};

const handleDrop = async (row) => {
  try {
    await ElMessageBox.confirm(`确定为 ${row.student_name} 退选 ${row.course_name}？`, '确认退课');
    await api.delete(`/enrollments/${row.id}`);
    ElMessage.success('退课成功');
    loadData();
  } catch (e) { if (e !== 'cancel') ElMessage.error('退课失败'); }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.search-bar { margin-bottom: 16px; }
</style>
