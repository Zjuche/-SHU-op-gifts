<template>
  <div class="page-container">
    <div class="page-header"><h3>选课管理</h3></div>
    <el-card>
      <el-form :inline="true" :model="form" class="enroll-form">
        <el-form-item label="学生">
          <el-select v-model="form.student_id" filterable placeholder="选择学生">
            <el-option v-for="s in students" :key="s.student_id" :label="`${s.name} (${s.student_id})`" :value="s.student_id" />
          </el-select>
        </el-form-item>
        <el-form-item label="课程">
          <el-select v-model="form.course_id" filterable placeholder="选择课程">
            <el-option v-for="c in courses" :key="c.course_id" :label="`${c.course_name} (${c.course_id}) - ${c.semester}`" :value="c.course_id" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleEnroll" :loading="loading">确认选课</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card style="margin-top:16px">
      <h4 style="margin:0 0 12px">当前选课记录</h4>
      <el-table :data="enrollments" stripe border>
        <el-table-column prop="student_id" label="学号" width="110" />
        <el-table-column prop="student_name" label="学生姓名" width="100" />
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column prop="select_time" label="选课时间" width="170" />
        <el-table-column label="成绩" width="80">
          <template #default="{ row }">{{ row.score ?? '未录入' }}</template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage } from 'element-plus';

const students = ref([]);
const courses = ref([]);
const enrollments = ref([]);
const loading = ref(false);
const form = ref({ student_id: '', course_id: '' });

const loadData = async () => {
  try {
    const [sRes, cRes, eRes] = await Promise.all([api.get('/students'), api.get('/courses'), api.get('/enrollments')]);
    students.value = sRes.data.data;
    courses.value = cRes.data.data;
    enrollments.value = eRes.data.data;
  } catch (e) { ElMessage.error('获取数据失败'); }
};

const handleEnroll = async () => {
  if (!form.value.student_id || !form.value.course_id) {
    ElMessage.warning('请选择学生和课程');
    return;
  }
  loading.value = true;
  try {
    await api.post('/enrollments', form.value);
    ElMessage.success('选课成功');
    form.value = { student_id: '', course_id: '' };
    loadData();
  } catch (e) { ElMessage.error(e.response?.data?.message || '选课失败'); }
  finally { loading.value = false; }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.enroll-form { display: flex; align-items: flex-end; gap: 8px; }
</style>
