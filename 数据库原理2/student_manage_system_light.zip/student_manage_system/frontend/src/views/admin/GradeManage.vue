<template>
  <div class="page-container">
    <div class="page-header"><h3>成绩管理</h3></div>
    <el-card>
      <div class="search-bar">
        <el-select v-model="filterStudent" filterable clearable placeholder="按学生筛选" @change="loadData">
          <el-option v-for="s in students" :key="s.student_id" :label="`${s.name} (${s.student_id})`" :value="s.student_id" />
        </el-select>
      </div>
      <el-table :data="enrollments" stripe border>
        <el-table-column prop="student_id" label="学号" width="110" />
        <el-table-column prop="student_name" label="学生姓名" width="100" />
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column label="成绩" width="160">
          <template #default="{ row }">
            <el-input-number
              v-model="row.editScore"
              :min="0" :max="100" :step="1" :precision="1"
              size="small" controls-position="right"
              style="width:120px"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="primary" @click="saveScore(row)">保存</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage } from 'element-plus';

const enrollments = ref([]);
const students = ref([]);
const filterStudent = ref('');

const loadData = async () => {
  try {
    const params = filterStudent.value ? { student_id: filterStudent.value } : {};
    const [eRes, sRes] = await Promise.all([api.get('/enrollments', params), api.get('/students')]);
    enrollments.value = eRes.data.data.map(e => ({ ...e, editScore: e.score ?? 0 }));
    students.value = sRes.data.data;
  } catch (e) { ElMessage.error('获取数据失败'); }
};

const saveScore = async (row) => {
  try {
    await api.put(`/enrollments/${row.id}/score`, { score: row.editScore });
    ElMessage.success(`${row.student_name} 的 ${row.course_name} 成绩已保存`);
    loadData();
  } catch (e) { ElMessage.error(e.response?.data?.message || '保存失败'); }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.search-bar { margin-bottom: 16px; }
</style>
