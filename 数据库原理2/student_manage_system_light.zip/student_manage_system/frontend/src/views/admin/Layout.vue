<template>
  <div class="admin-layout">
    <el-container>
      <el-aside width="200px">
        <el-menu
          :default-active="$route.path"
          class="el-menu-vertical"
          router
        >
          <el-menu-item index="/admin/dashboard">
            <el-icon><Histogram /></el-icon>
            <span>仪表盘</span>
          </el-menu-item>
          <el-menu-item index="/admin/student">
            <el-icon><User /></el-icon>
            <span>学生管理</span>
          </el-menu-item>
          <el-menu-item index="/admin/teacher">
            <el-icon><Avatar /></el-icon>
            <span>教师管理</span>
          </el-menu-item>
          <el-menu-item index="/admin/course">
            <el-icon><Notebook /></el-icon>
            <span>课程管理</span>
          </el-menu-item>
          <el-menu-item index="/admin/select">
            <el-icon><CircleCheck /></el-icon>
            <span>选课管理</span>
          </el-menu-item>
          <el-menu-item index="/admin/drop">
            <el-icon><CircleClose /></el-icon>
            <span>退课管理</span>
          </el-menu-item>
          <el-menu-item index="/admin/grade">
            <el-icon><Edit /></el-icon>
            <span>成绩管理</span>
          </el-menu-item>
          <el-menu-item index="/admin/statistics">
            <el-icon><TrendCharts /></el-icon>
            <span>统计查询</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-container>
        <el-header>
          <div class="header-content">
            <h2>学生选课成绩管理系统</h2>
            <div class="user-info">
              <span>{{ userStore.user?.name }}</span>
              <el-button type="danger" size="small" @click="handleLogout">退出</el-button>
            </div>
          </div>
        </el-header>
        <el-main>
          <router-view />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import { Histogram, User, Avatar, Notebook, CircleCheck, CircleClose, Edit, TrendCharts } from '@element-plus/icons-vue';
import { useAuthStore } from '@/stores/auth';
import { useRouter } from 'vue-router';

const router = useRouter();
const userStore = useAuthStore();

const handleLogout = () => {
  userStore.logout();
  router.push('/login');
};
</script>

<style scoped>
.admin-layout {
  min-height: 100vh;
}

.el-aside {
  background: var(--panel-bg);
  border-right: 1px solid var(--border-control);
}

.el-menu-vertical {
  height: 100%;
}

.el-header {
  background: var(--panel-bg-alt);
  border-bottom: 1px solid var(--border-strong);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.header-content h2 {
  margin: 0;
  color: var(--text-strong);
  font-size: 15px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.el-main {
  background: var(--app-bg);
  padding: 0;
}
</style>
