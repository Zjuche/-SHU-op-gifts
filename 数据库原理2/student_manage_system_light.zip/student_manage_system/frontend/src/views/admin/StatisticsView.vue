<template>
  <div class="page-container">
    <div class="page-header">
      <h3>统计查询</h3>
      <el-select v-model="selectedSemester" class="semester-select" clearable placeholder="全部学期">
        <el-option v-for="semester in semesterOptions" :key="semester" :label="semester" :value="semester" />
      </el-select>
    </div>
    <el-card>
      <h4>学生成绩统计</h4>
      <el-table :data="studentStats" stripe border style="margin-bottom:24px">
        <el-table-column prop="student_id" label="学号" width="110" />
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column prop="class_name" label="班级" width="120" />
        <el-table-column prop="major" label="专业" />
        <el-table-column prop="course_count" label="选课数" width="80" />
        <el-table-column prop="avg_score" label="平均分" width="80" />
        <el-table-column prop="max_score" label="最高分" width="80" />
        <el-table-column prop="min_score" label="最低分" width="80" />
      </el-table>

      <h4>课程成绩统计</h4>
      <el-table :data="filteredCourseStats" stripe border style="margin-bottom:24px">
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column prop="teacher_name" label="任课教师" width="100" />
        <el-table-column prop="credit" label="学分" width="70" />
        <el-table-column prop="student_count" label="选课人数" width="90" />
        <el-table-column prop="avg_score" label="平均分" width="80" />
        <el-table-column prop="max_score" label="最高分" width="80" />
        <el-table-column prop="min_score" label="最低分" width="80" />
      </el-table>

      <h4>教师教学统计</h4>
      <el-table :data="teacherStats" stripe border>
        <el-table-column prop="teacher_id" label="工号" width="100" />
        <el-table-column prop="teacher_name" label="姓名" width="100" />
        <el-table-column prop="course_count" label="开课数" width="80" />
        <el-table-column prop="enrollment_count" label="选课人数" width="90" />
        <el-table-column prop="avg_score" label="平均分" width="80" />
        <el-table-column label="及格率" width="80">
          <template #default="{ row }">{{ row.pass_rate }}%</template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { computed, ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage } from 'element-plus';
import { sortSemesterList } from '@/utils/semester';

const studentStats = ref([]);
const courseStats = ref([]);
const teacherStats = ref([]);
const selectedSemester = ref('');

const semesterOptions = computed(() => sortSemesterList(courseStats.value.map(course => course.semester)));
const filteredCourseStats = computed(() => {
  if (!selectedSemester.value) {
    return courseStats.value;
  }

  return courseStats.value.filter(course => course.semester === selectedSemester.value);
});

const loadData = async () => {
  try {
    const res = await api.get('/statistics');
    studentStats.value = res.data.data.studentStats;
    courseStats.value = res.data.data.courseStats;
    teacherStats.value = res.data.data.teacherStats || [];
  } catch (e) { ElMessage.error('获取统计数据失败'); }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; gap: 12px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
h4 { margin: 0 0 12px; color: #303133; }
.semester-select { width: 180px; }
</style>
