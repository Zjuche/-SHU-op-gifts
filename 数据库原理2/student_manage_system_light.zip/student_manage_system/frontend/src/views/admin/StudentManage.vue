<template>
  <div class="page-container">
    <div class="page-header">
      <h3>学生管理</h3>
      <el-button type="primary" @click="showAddDialog = true">添加学生</el-button>
    </div>

    <el-card>
      <div class="search-bar">
        <el-input v-model="searchId" placeholder="按学号搜索" clearable style="width:200px" @clear="loadList" @keyup.enter="loadList" />
        <el-input v-model="searchName" placeholder="按姓名搜索" clearable style="width:200px" @clear="loadList" @keyup.enter="loadList" />
        <el-button type="primary" @click="loadList">搜索</el-button>
      </div>

      <el-table :data="list" stripe border style="width:100%">
        <el-table-column prop="student_id" label="学号" width="120" />
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column prop="gender" label="性别" width="80" />
        <el-table-column prop="age" label="年龄" width="80" />
        <el-table-column prop="class_name" label="班级" width="140" />
        <el-table-column prop="major" label="专业" />
        <el-table-column prop="phone" label="电话" width="140" />
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="editRow(row)">编辑</el-button>
            <el-button size="small" type="danger" @click="deleteRow(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 添加/编辑弹窗 -->
    <el-dialog :title="editingRow ? '编辑学生' : '添加学生'" v-model="showAddDialog" width="500px" @close="resetForm">
      <el-form :model="form" :rules="formRules" ref="formRef" label-width="80px">
        <el-form-item label="学号" prop="student_id">
          <el-input v-model="form.student_id" :disabled="!!editingRow" placeholder="如 2023005" />
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="性别">
          <el-radio-group v-model="form.gender">
            <el-radio label="男">男</el-radio>
            <el-radio label="女">女</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="年龄">
          <el-input-number v-model="form.age" :min="15" :max="50" />
        </el-form-item>
        <el-form-item label="班级" prop="class_name">
          <el-input v-model="form.class_name" placeholder="如 计科 2301" />
        </el-form-item>
        <el-form-item label="专业" prop="major">
          <el-input v-model="form.major" />
        </el-form-item>
        <el-form-item label="电话">
          <el-input v-model="form.phone" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage, ElMessageBox } from 'element-plus';

const list = ref([]);
const searchId = ref('');
const searchName = ref('');
const showAddDialog = ref(false);
const editingRow = ref(null);
const formRef = ref(null);

const form = ref({ student_id: '', name: '', gender: '男', age: 20, class_name: '', major: '', phone: '' });

const formRules = {
  student_id: [{ required: true, message: '请输入学号', trigger: 'blur' }],
  name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
  class_name: [{ required: true, message: '请输入班级', trigger: 'blur' }],
  major: [{ required: true, message: '请输入专业', trigger: 'blur' }],
};

const loadList = async () => {
  try {
    const params = {};
    if (searchId.value) params.student_id = searchId.value;
    if (searchName.value) params.name = searchName.value;
    const res = await api.get('/students', params);
    list.value = res.data.data;
  } catch (e) {
    ElMessage.error('获取学生列表失败');
  }
};

const editRow = (row) => {
  editingRow.value = row;
  form.value = { ...row };
  showAddDialog.value = true;
};

const deleteRow = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除学生 ${row.name}？`, '确认');
    await api.delete(`/students/${row.student_id}`);
    ElMessage.success('删除成功');
    loadList();
  } catch (e) {
    if (e !== 'cancel') ElMessage.error('删除失败');
  }
};

const resetForm = () => {
  editingRow.value = null;
  form.value = { student_id: '', name: '', gender: '男', age: 20, class_name: '', major: '', phone: '' };
};

const submitForm = async () => {
  if (!formRef.value) return;
  await formRef.value.validate(async (valid) => {
    if (!valid) return;
    try {
      if (editingRow.value) {
        await api.put(`/students/${form.value.student_id}`, form.value);
        ElMessage.success('修改成功');
      } else {
        await api.post('/students', form.value);
        ElMessage.success('添加成功');
      }
      showAddDialog.value = false;
      loadList();
    } catch (e) {
      ElMessage.error(e.response?.data?.message || '操作失败');
    }
  });
};

onMounted(loadList);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.search-bar { display: flex; gap: 10px; margin-bottom: 16px; }
</style>
