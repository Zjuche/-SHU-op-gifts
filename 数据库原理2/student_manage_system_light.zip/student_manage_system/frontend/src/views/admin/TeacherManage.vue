<template>
  <div class="page-container">
    <div class="page-header">
      <h3>教师管理</h3>
      <el-button type="primary" @click="showAddDialog = true">添加教师</el-button>
    </div>

    <el-card>
      <div class="search-bar">
        <el-input v-model="searchId" placeholder="按工号搜索" clearable style="width:200px" @clear="loadList" @keyup.enter="loadList" />
        <el-input v-model="searchName" placeholder="按姓名搜索" clearable style="width:200px" @clear="loadList" @keyup.enter="loadList" />
        <el-button type="primary" @click="loadList">搜索</el-button>
      </div>

      <el-table :data="list" stripe border style="width:100%">
        <el-table-column prop="teacher_id" label="工号" width="120" />
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column prop="gender" label="性别" width="80" />
        <el-table-column prop="title" label="职称" width="120" />
        <el-table-column prop="department" label="所属院系" />
        <el-table-column prop="phone" label="电话" width="140" />
        <el-table-column label="操作" width="160" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="editRow(row)">编辑</el-button>
            <el-button size="small" type="danger" @click="deleteRow(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 添加/编辑弹窗 -->
    <el-dialog :title="editingRow ? '编辑教师' : '添加教师'" v-model="showAddDialog" width="500px" @close="resetForm">
      <el-form :model="form" :rules="formRules" ref="formRef" label-width="80px">
        <el-form-item label="工号" prop="teacher_id">
          <el-input v-model="form.teacher_id" :disabled="!!editingRow" placeholder="如 T004" />
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="性别">
          <el-radio-group v-model="form.gender">
            <el-radio label="男">男</el-radio>
            <el-radio label="女">女</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="职称">
          <el-select v-model="form.title" placeholder="请选择职称" style="width:100%">
            <el-option label="教授" value="教授" />
            <el-option label="副教授" value="副教授" />
            <el-option label="讲师" value="讲师" />
            <el-option label="助教" value="助教" />
          </el-select>
        </el-form-item>
        <el-form-item label="院系">
          <el-input v-model="form.department" placeholder="如 计算机学院" />
        </el-form-item>
        <el-form-item label="电话">
          <el-input v-model="form.phone" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage, ElMessageBox } from 'element-plus';

const list = ref([]);
const searchId = ref('');
const searchName = ref('');
const showAddDialog = ref(false);
const editingRow = ref(null);
const formRef = ref(null);

const form = ref({ teacher_id: '', name: '', gender: '男', title: '', department: '', phone: '' });

const formRules = {
  teacher_id: [{ required: true, message: '请输入工号', trigger: 'blur' }],
  name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
};

const loadList = async () => {
  try {
    const params = {};
    if (searchId.value) params.teacher_id = searchId.value;
    if (searchName.value) params.name = searchName.value;
    const res = await api.get('/teachers', params);
    list.value = res.data.data;
  } catch (e) {
    ElMessage.error('获取教师列表失败');
  }
};

const editRow = (row) => {
  editingRow.value = row;
  form.value = { ...row };
  showAddDialog.value = true;
};

const deleteRow = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除教师 ${row.name}？`, '确认');
    await api.delete(`/teachers/${row.teacher_id}`);
    ElMessage.success('删除成功');
    loadList();
  } catch (e) {
    if (e !== 'cancel') ElMessage.error(e.response?.data?.message || '删除失败');
  }
};

const resetForm = () => {
  editingRow.value = null;
  form.value = { teacher_id: '', name: '', gender: '男', title: '', department: '', phone: '' };
};

const submitForm = async () => {
  if (!formRef.value) return;
  await formRef.value.validate(async (valid) => {
    if (!valid) return;
    try {
      if (editingRow.value) {
        await api.put(`/teachers/${form.value.teacher_id}`, form.value);
        ElMessage.success('修改成功');
      } else {
        await api.post('/teachers', form.value);
        ElMessage.success('添加成功');
      }
      showAddDialog.value = false;
      loadList();
    } catch (e) {
      ElMessage.error(e.response?.data?.message || '操作失败');
    }
  });
};

onMounted(loadList);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.search-bar { display: flex; gap: 10px; margin-bottom: 16px; }
</style>
