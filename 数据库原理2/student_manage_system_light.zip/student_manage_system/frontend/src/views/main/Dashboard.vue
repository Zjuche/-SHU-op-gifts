<template>
  <div class="placeholder">
    <el-empty description="页面开发中..." />
  </div>
</template>

<style scoped>
.placeholder {
  min-height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
