<template>
  <div class="page-container">
    <div class="page-header"><h3>退课</h3></div>
    <el-card>
      <el-table :data="myEnrollments" stripe border>
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column prop="teacher_name" label="任课教师" width="100" />
        <el-table-column prop="select_time" label="选课时间" width="170" />
        <el-table-column label="成绩" width="80">
          <template #default="{ row }">{{ row.score ?? '未录入' }}</template>
        </el-table-column>
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="danger" @click="handleDrop(row)">退课</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="myEnrollments.length === 0" description="暂无选课记录" />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { useAuthStore } from '@/stores/auth';
import { ElMessage, ElMessageBox } from 'element-plus';

const authStore = useAuthStore();
const myEnrollments = ref([]);

const loadData = async () => {
  try {
    const res = await api.get('/enrollments', { student_id: authStore.user.student_id });
    myEnrollments.value = res.data.data;
  } catch (e) { ElMessage.error('获取数据失败'); }
};

const handleDrop = async (row) => {
  try {
    await ElMessageBox.confirm(`确定退选 ${row.course_name}？`, '确认退课');
    await api.delete(`/enrollments/${row.id}`);
    ElMessage.success('退课成功');
    loadData();
  } catch (e) { if (e !== 'cancel') ElMessage.error('退课失败'); }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
</style>
