<template>
  <div class="student-home">
    <el-card>
      <h3>欢迎，{{ userStore.user?.name }}</h3>
      <p>学号：{{ userStore.user?.student_id }}</p>
      <p>班级：{{ userStore.user?.class_name }}</p>
      <p>专业：{{ userStore.user?.major }}</p>
    </el-card>
  </div>
</template>

<script setup>
import { useAuthStore } from '@/stores/auth';

const userStore = useAuthStore();
</script>
