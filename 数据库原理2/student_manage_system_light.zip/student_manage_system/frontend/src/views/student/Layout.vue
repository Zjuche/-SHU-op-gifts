<template>
  <div class="student-layout">
    <el-container>
      <el-aside width="200px">
        <el-menu
          :default-active="$route.path"
          class="el-menu-vertical"
          router
        >
          <el-menu-item index="/student/home">
            <el-icon><House /></el-icon>
            <span>个人中心</span>
          </el-menu-item>
          <el-menu-item index="/student/select-course">
            <el-icon><CirclePlus /></el-icon>
            <span>选课</span>
          </el-menu-item>
          <el-menu-item index="/student/drop-course">
            <el-icon><Delete /></el-icon>
            <span>退课</span>
          </el-menu-item>
          <el-menu-item index="/student/my-grade">
            <el-icon><Document /></el-icon>
            <span>成绩查询</span>
          </el-menu-item>
          <el-menu-item index="/student/statistics">
            <el-icon><TrendCharts /></el-icon>
            <span>学习统计</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-container>
        <el-header>
          <div class="header-content">
            <h2>学生个人中心</h2>
            <div class="user-info">
              <span>{{ userStore.user?.name }}</span>
              <el-button type="danger" size="small" @click="handleLogout">退出</el-button>
            </div>
          </div>
        </el-header>
        <el-main>
          <router-view />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import { House, CirclePlus, Delete, Document, TrendCharts } from '@element-plus/icons-vue';
import { useAuthStore } from '@/stores/auth';
import { useRouter } from 'vue-router';

const router = useRouter();
const userStore = useAuthStore();

const handleLogout = () => {
  userStore.logout();
  router.push('/login');
};
</script>

<style scoped>
.student-layout {
  min-height: 100vh;
}

.el-aside {
  background: var(--panel-bg);
  border-right: 1px solid var(--border-control);
}

.el-menu-vertical {
  height: 100%;
}

.el-header {
  background: var(--panel-bg-alt);
  border-bottom: 1px solid var(--border-strong);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.header-content h2 {
  margin: 0;
  color: var(--text-strong);
  font-size: 15px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.el-main {
  background: var(--app-bg);
  padding: 0;
}
</style>
