<template>
  <div class="page-container">
    <div class="page-header"><h3>成绩查询</h3></div>
    <el-card>
      <el-table :data="myEnrollments" stripe border>
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column prop="teacher_name" label="任课教师" width="100" />
        <el-table-column label="成绩" width="100">
          <template #default="{ row }">
            <el-tag v-if="row.score !== null" :type="row.score >= 60 ? 'success' : 'danger'">{{ row.score }}</el-tag>
            <span v-else style="color: var(--text-muted)">未录入</span>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="myEnrollments.length === 0" description="暂无成绩记录" />

      <div v-if="myEnrollments.length > 0" class="summary">
        <p>已选课程数：<strong>{{ myEnrollments.length }}</strong></p>
        <p>已出成绩数：<strong>{{ scored.length }}</strong></p>
        <p v-if="scored.length > 0">
          平均分：<strong>{{ avgScore }}</strong> ·
          最高分：<strong>{{ maxScore }}</strong> ·
          最低分：<strong>{{ minScore }}</strong>
        </p>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import api from '@/api';
import { useAuthStore } from '@/stores/auth';
import { ElMessage } from 'element-plus';

const authStore = useAuthStore();
const myEnrollments = ref([]);

const scored = computed(() => myEnrollments.value.filter(e => e.score !== null));
const avgScore = computed(() => scored.value.length ? (scored.value.reduce((s, e) => s + e.score, 0) / scored.value.length).toFixed(1) : '-');
const maxScore = computed(() => scored.value.length ? Math.max(...scored.value.map(e => e.score)) : '-');
const minScore = computed(() => scored.value.length ? Math.min(...scored.value.map(e => e.score)) : '-');

const loadData = async () => {
  try {
    const res = await api.get('/enrollments', { student_id: authStore.user.student_id });
    myEnrollments.value = res.data.data;
  } catch (e) { ElMessage.error('获取数据失败'); }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.summary { margin-top: 12px; padding: 12px; background: var(--panel-bg-alt); border: 1px solid var(--border-soft); border-radius: 0; }
.summary p { margin: 4px 0; color: var(--text-muted); }
.summary strong { color: var(--text-strong); }
</style>
