<template>
  <div class="page-container">
    <div class="page-header">
      <h3>选课</h3>
      <el-select v-model="selectedSemester" class="semester-select" placeholder="选择学期">
        <el-option v-for="semester in semesterOptions" :key="semester" :label="semester" :value="semester" />
      </el-select>
    </div>
    <el-card>
      <el-table :data="availableCourses" stripe border>
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column prop="credit" label="学分" width="70" />
        <el-table-column prop="teacher_name" label="任课教师" width="100" />
        <el-table-column label="已选人数" width="90">
          <template #default="{ row }">{{ row.selected_count ?? 0 }}</template>
        </el-table-column>
        <el-table-column prop="classroom" label="教室" width="100" />
        <el-table-column prop="max_students" label="最大人数" width="90" />
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button
              size="small" type="primary"
              :disabled="isEnrolled(row.course_id)"
              @click="handleSelect(row)"
            >{{ isEnrolled(row.course_id) ? '已选' : '选课' }}</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { computed, ref, onMounted } from 'vue';
import api from '@/api';
import { useAuthStore } from '@/stores/auth';
import { ElMessage } from 'element-plus';
import { getCurrentSemester, sortSemesterList } from '@/utils/semester';

const authStore = useAuthStore();
const allCourses = ref([]);
const myEnrollments = ref([]);
const selectedSemester = ref(getCurrentSemester());

const semesterOptions = computed(() => sortSemesterList(allCourses.value.map(course => course.semester)));
const availableCourses = computed(() => {
  if (!selectedSemester.value) {
    return allCourses.value;
  }

  return allCourses.value.filter(course => course.semester === selectedSemester.value);
});
const semesterEnrollments = computed(() => {
  if (!selectedSemester.value) {
    return myEnrollments.value;
  }

  return myEnrollments.value.filter(enrollment => enrollment.semester === selectedSemester.value);
});

const loadData = async () => {
  try {
    const [cRes, eRes] = await Promise.all([
      api.get('/courses'),
      api.get('/enrollments', { student_id: authStore.user.student_id })
    ]);
    allCourses.value = cRes.data.data;
    myEnrollments.value = eRes.data.data;

    if (semesterOptions.value.length > 0 && !semesterOptions.value.includes(selectedSemester.value)) {
      selectedSemester.value = semesterOptions.value[0];
    }
  } catch (e) { ElMessage.error('获取数据失败'); }
};

const isEnrolled = (courseId) => semesterEnrollments.value.some(e => e.course_id === courseId);

const handleSelect = async (course) => {
  try {
    await api.post('/enrollments', { student_id: authStore.user.student_id, course_id: course.course_id });
    ElMessage.success(`成功选择 ${course.course_name}`);
    loadData();
  } catch (e) { ElMessage.error(e.response?.data?.message || '选课失败'); }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; gap: 12px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.semester-select { width: 180px; }
</style>
