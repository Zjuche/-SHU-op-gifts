<template>
  <div class="page-container">
    <div class="page-header">
      <h3>学习统计</h3>
    </div>

    <div class="summary-grid">
      <div class="summary-box">
        <span class="summary-label">已选课程</span>
        <strong class="summary-value">{{ overview.course_count ?? 0 }}</strong>
      </div>
      <div class="summary-box">
        <span class="summary-label">已修学分</span>
        <strong class="summary-value">{{ overview.selected_credit ?? '0.0' }}</strong>
      </div>
      <div class="summary-box">
        <span class="summary-label">平均分</span>
        <strong class="summary-value">{{ overview.avg_score ?? '0.0' }}</strong>
      </div>
      <div class="summary-box">
        <span class="summary-label">及格率</span>
        <strong class="summary-value">{{ overview.pass_rate ?? '0.0' }}%</strong>
      </div>
    </div>

    <el-card>
      <div class="section-title">学期汇总</div>
      <el-table :data="semesterStats" stripe border>
        <el-table-column prop="semester" label="学期" width="130" />
        <el-table-column prop="course_count" label="课程数" width="90" />
        <el-table-column prop="credit_sum" label="学分" width="90" />
        <el-table-column prop="scored_count" label="已出成绩" width="100" />
        <el-table-column prop="avg_score" label="平均分" width="100" />
      </el-table>
    </el-card>

    <el-card class="stack-card">
      <div class="section-title">成绩分布</div>
      <el-table :data="gradeDistribution" stripe border>
        <el-table-column prop="grade_band" label="区间" width="120" />
        <el-table-column prop="count" label="课程数" width="100" />
      </el-table>
    </el-card>

    <el-card class="stack-card">
      <div class="section-title">课程明细</div>
      <el-table :data="courseGrades" stripe border>
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="130" />
        <el-table-column prop="credit" label="学分" width="80" />
        <el-table-column prop="teacher_name" label="教师" width="110" />
        <el-table-column label="成绩" width="100">
          <template #default="{ row }">
            <el-tag v-if="row.score !== null" :type="Number(row.score) >= 60 ? 'success' : 'danger'">
              {{ row.score }}
            </el-tag>
            <span v-else class="muted">未录入</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage } from 'element-plus';

const overview = ref({});
const semesterStats = ref([]);
const gradeDistribution = ref([]);
const courseGrades = ref([]);

const loadData = async () => {
  try {
    const res = await api.get('/student/statistics');
    overview.value = res.data.data.overview || {};
    semesterStats.value = res.data.data.semesterStats || [];
    gradeDistribution.value = res.data.data.gradeDistribution || [];
    courseGrades.value = res.data.data.courseGrades || [];
  } catch (error) {
    ElMessage.error(error.response?.data?.message || '获取学习统计失败');
  }
};

onMounted(loadData);
</script>
