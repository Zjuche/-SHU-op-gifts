<template>
  <div class="page-container">
    <div class="page-header">
      <h3>所授课程</h3>
      <el-select v-model="selectedSemester" class="semester-select" placeholder="选择学期">
        <el-option v-for="semester in semesterOptions" :key="semester" :label="semester" :value="semester" />
      </el-select>
    </div>
    <el-card>
      <el-table :data="myCourses" stripe border>
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column prop="credit" label="学分" width="70" />
        <el-table-column label="已选人数" width="90">
          <template #default="{ row }">{{ row.enrolled_count ?? row.selected_count ?? getEnrollCount(row.course_id) }}</template>
        </el-table-column>
        <el-table-column label="平均分" width="90">
          <template #default="{ row }">{{ row.avg_score }}</template>
        </el-table-column>
        <el-table-column label="及格率" width="90">
          <template #default="{ row }">{{ row.pass_rate }}</template>
        </el-table-column>
        <el-table-column prop="max_students" label="最大人数" width="90" />
        <el-table-column prop="classroom" label="教室" width="100" />
      </el-table>
      <el-empty v-if="myCourses.length === 0" description="暂无授课记录" />
    </el-card>
  </div>
</template>

<script setup>
import { computed, ref, onMounted } from 'vue';
import api from '@/api';
import { useAuthStore } from '@/stores/auth';
import { ElMessage } from 'element-plus';
import { getCurrentSemester, sortSemesterList } from '@/utils/semester';

const authStore = useAuthStore();
const allCourses = ref([]);
const allEnrollments = ref([]);
const selectedSemester = ref(getCurrentSemester());

const semesterOptions = computed(() => sortSemesterList(allCourses.value.map(course => course.semester)));
const semesterEnrollments = computed(() => {
  if (!selectedSemester.value) {
    return allEnrollments.value;
  }

  return allEnrollments.value.filter(enrollment => enrollment.semester === selectedSemester.value);
});
const myCourses = computed(() => {
  const filteredCourses = selectedSemester.value
    ? allCourses.value.filter(course => course.semester === selectedSemester.value)
    : allCourses.value;

  return filteredCourses.map(course => {
    const courseEnrollments = semesterEnrollments.value.filter(enrollment => enrollment.course_id === course.course_id);
    const scored = courseEnrollments.filter(enrollment => enrollment.score !== null);
    const avgScore = scored.length
      ? (scored.reduce((sum, enrollment) => sum + Number(enrollment.score), 0) / scored.length).toFixed(1)
      : '-';
    const passRate = scored.length
      ? `${((scored.filter(enrollment => Number(enrollment.score) >= 60).length / scored.length) * 100).toFixed(1)}%`
      : '-';

    return {
      ...course,
      enrolled_count: courseEnrollments.length,
      avg_score: avgScore,
      pass_rate: passRate
    };
  });
});

const getEnrollCount = (courseId) => semesterEnrollments.value.filter(e => e.course_id === courseId).length;

const loadData = async () => {
  try {
    const [cRes, eRes] = await Promise.all([
      api.get('/courses', { teacher_id: authStore.user.teacher_id }),
      api.get('/enrollments', { teacher_id: authStore.user.teacher_id })
    ]);
    allCourses.value = cRes.data.data;
    allEnrollments.value = eRes.data.data;

    if (semesterOptions.value.length > 0 && !semesterOptions.value.includes(selectedSemester.value)) {
      selectedSemester.value = semesterOptions.value[0];
    }
  } catch (e) { ElMessage.error('获取数据失败'); }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; gap: 12px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.semester-select { width: 180px; }
</style>
