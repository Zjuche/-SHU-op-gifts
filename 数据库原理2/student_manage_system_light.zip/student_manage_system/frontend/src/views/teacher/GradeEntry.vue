<template>
  <div class="page-container">
    <div class="page-header"><h3>成绩录入</h3></div>
    <el-card>
      <div class="search-bar">
        <el-select v-model="selectedCourse" placeholder="选择课程" @change="filterByCourse">
          <el-option v-for="c in myCourses" :key="c.course_id" :label="`${c.course_name} (${c.course_id}) - ${c.semester}`" :value="c.course_id" />
        </el-select>
      </div>
      <el-table :data="filteredEnrollments" stripe border>
        <el-table-column prop="student_id" label="学号" width="110" />
        <el-table-column prop="student_name" label="学生姓名" width="120" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="110" />
        <el-table-column label="成绩" width="160">
          <template #default="{ row }">
            <el-input-number
              v-model="row.editScore"
              :min="0" :max="100" :step="1" :precision="1"
              size="small" controls-position="right"
              style="width:120px"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="100" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="primary" @click="saveScore(row)">保存</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="filteredEnrollments.length === 0" description="请选择课程" />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { useAuthStore } from '@/stores/auth';
import { ElMessage } from 'element-plus';

const authStore = useAuthStore();
const myCourses = ref([]);
const allEnrollments = ref([]);
const filteredEnrollments = ref([]);
const selectedCourse = ref('');

const loadData = async () => {
  try {
    const [cRes, eRes] = await Promise.all([
      api.get('/courses', { teacher_id: authStore.user.teacher_id }),
      api.get('/enrollments', { teacher_id: authStore.user.teacher_id })
    ]);
    myCourses.value = cRes.data.data;
    allEnrollments.value = eRes.data.data.map(e => ({ ...e, editScore: e.score ?? 0 }));
    if (selectedCourse.value) filterByCourse();
  } catch (e) { ElMessage.error('获取数据失败'); }
};

const filterByCourse = () => {
  filteredEnrollments.value = allEnrollments.value.filter(e => e.course_id === selectedCourse.value);
};

const saveScore = async (row) => {
  try {
    await api.put(`/enrollments/${row.id}/score`, { score: row.editScore });
    ElMessage.success(`${row.student_name} 成绩已保存`);
    loadData();
  } catch (e) { ElMessage.error(e.response?.data?.message || '保存失败'); }
};

onMounted(loadData);
</script>

<style scoped>
.page-container { padding: 20px; }
.page-header { margin-bottom: 16px; }
.page-header h3 { margin: 0; font-size: 15px; color: var(--text-strong); }
.search-bar { margin-bottom: 16px; }
</style>
