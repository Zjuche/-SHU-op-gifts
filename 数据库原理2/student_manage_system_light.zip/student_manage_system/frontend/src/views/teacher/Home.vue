<template>
  <div class="teacher-home">
    <el-card>
      <h3>欢迎，{{ userStore.user?.name }}</h3>
      <p>工号：{{ userStore.user?.teacher_id }}</p>
      <p>职称：{{ userStore.user?.title }}</p>
      <p>院系：{{ userStore.user?.department }}</p>
    </el-card>
  </div>
</template>

<script setup>
import { useAuthStore } from '@/stores/auth';

const userStore = useAuthStore();
</script>
