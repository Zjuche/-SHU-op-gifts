<template>
  <div class="teacher-layout">
    <el-container>
      <el-aside width="200px">
        <el-menu
          :default-active="$route.path"
          class="el-menu-vertical"
          router
        >
          <el-menu-item index="/teacher/home">
            <el-icon><House /></el-icon>
            <span>个人中心</span>
          </el-menu-item>
          <el-menu-item index="/teacher/grade-entry">
            <el-icon><Edit /></el-icon>
            <span>成绩录入</span>
          </el-menu-item>
          <el-menu-item index="/teacher/course-list">
            <el-icon><Notebook /></el-icon>
            <span>所授课程</span>
          </el-menu-item>
          <el-menu-item index="/teacher/teaching-log">
            <el-icon><Document /></el-icon>
            <span>教学日志</span>
          </el-menu-item>
          <el-menu-item index="/teacher/statistics">
            <el-icon><TrendCharts /></el-icon>
            <span>统计分析</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-container>
        <el-header>
          <div class="header-content">
            <h2>教师工作台</h2>
            <div class="user-info">
              <span>{{ userStore.user?.name }}</span>
              <el-button type="danger" size="small" @click="handleLogout">退出</el-button>
            </div>
          </div>
        </el-header>
        <el-main>
          <router-view />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import { House, Edit, Notebook, Document, TrendCharts } from '@element-plus/icons-vue';
import { useAuthStore } from '@/stores/auth';
import { useRouter } from 'vue-router';

const router = useRouter();
const userStore = useAuthStore();

const handleLogout = () => {
  userStore.logout();
  router.push('/login');
};
</script>

<style scoped>
.teacher-layout {
  min-height: 100vh;
}

.el-aside {
  background: var(--panel-bg);
  border-right: 1px solid var(--border-control);
}

.el-menu-vertical {
  height: 100%;
}

.el-header {
  background: var(--panel-bg-alt);
  border-bottom: 1px solid var(--border-strong);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.header-content h2 {
  margin: 0;
  color: var(--text-strong);
  font-size: 15px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.el-main {
  background: var(--app-bg);
  padding: 0;
}
</style>
