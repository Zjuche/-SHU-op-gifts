<template>
  <div class="page-container">
    <div class="page-header">
      <h3>统计分析</h3>
    </div>

    <div class="summary-grid">
      <div class="summary-box">
        <span class="summary-label">授课数</span>
        <strong class="summary-value">{{ overview.course_count ?? 0 }}</strong>
      </div>
      <div class="summary-box">
        <span class="summary-label">选课人数</span>
        <strong class="summary-value">{{ overview.enrollment_count ?? 0 }}</strong>
      </div>
      <div class="summary-box">
        <span class="summary-label">平均分</span>
        <strong class="summary-value">{{ overview.avg_score ?? '0.0' }}</strong>
      </div>
      <div class="summary-box">
        <span class="summary-label">及格率</span>
        <strong class="summary-value">{{ overview.pass_rate ?? '0.0' }}%</strong>
      </div>
    </div>

    <el-card>
      <div class="section-title">课程表现</div>
      <el-table :data="courseStats" stripe border>
        <el-table-column prop="course_id" label="课程号" width="100" />
        <el-table-column prop="course_name" label="课程名" />
        <el-table-column prop="semester" label="学期" width="130" />
        <el-table-column prop="enrollment_count" label="选课人数" width="100" />
        <el-table-column prop="scored_count" label="已录成绩" width="100" />
        <el-table-column prop="avg_score" label="平均分" width="90" />
        <el-table-column prop="max_score" label="最高分" width="90" />
        <el-table-column prop="min_score" label="最低分" width="90" />
        <el-table-column label="及格率" width="90">
          <template #default="{ row }">{{ row.pass_rate }}%</template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card class="stack-card">
      <div class="section-title">学期汇总</div>
      <el-table :data="semesterStats" stripe border>
        <el-table-column prop="semester" label="学期" width="130" />
        <el-table-column prop="course_count" label="开课数" width="90" />
        <el-table-column prop="enrollment_count" label="选课人数" width="100" />
        <el-table-column prop="scored_count" label="已录成绩" width="100" />
        <el-table-column prop="avg_score" label="平均分" width="90" />
      </el-table>
    </el-card>

    <el-card class="stack-card">
      <div class="section-title">近期教学日志</div>
      <el-table :data="recentLogs" stripe border>
        <el-table-column prop="teaching_date" label="日期" width="120" />
        <el-table-column prop="course_name" label="课程" width="160" />
        <el-table-column prop="topic" label="主题" />
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage } from 'element-plus';

const overview = ref({});
const courseStats = ref([]);
const semesterStats = ref([]);
const recentLogs = ref([]);

const loadData = async () => {
  try {
    const res = await api.get('/teacher/statistics');
    overview.value = res.data.data.overview || {};
    courseStats.value = res.data.data.courseStats || [];
    semesterStats.value = res.data.data.semesterStats || [];
    recentLogs.value = res.data.data.recentLogs || [];
  } catch (error) {
    ElMessage.error(error.response?.data?.message || '获取教师统计失败');
  }
};

onMounted(loadData);
</script>
