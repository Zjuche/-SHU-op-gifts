<template>
  <div class="page-container">
    <div class="page-header">
      <h3>教学日志</h3>
      <el-button type="primary" @click="openCreate">新增日志</el-button>
    </div>

    <el-card>
      <div class="search-bar">
        <el-select v-model="filterCourse" clearable placeholder="按课程筛选" @change="loadLogs">
          <el-option
            v-for="course in courses"
            :key="course.course_id"
            :label="`${course.course_name} (${course.course_id}) - ${course.semester}`"
            :value="course.course_id"
          />
        </el-select>
      </div>

      <el-table :data="logs" stripe border>
        <el-table-column prop="teaching_date" label="日期" width="120" />
        <el-table-column prop="course_name" label="课程" width="160" />
        <el-table-column prop="topic" label="主题" min-width="160" />
        <el-table-column prop="content" label="课堂内容" min-width="220" show-overflow-tooltip />
        <el-table-column prop="homework" label="课后任务" min-width="180" show-overflow-tooltip />
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="openEdit(row)">编辑</el-button>
            <el-button size="small" type="danger" @click="removeLog(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="logs.length === 0" description="暂无教学日志" />
    </el-card>

    <el-dialog :title="editingRow ? '编辑教学日志' : '新增教学日志'" v-model="dialogVisible" width="620px" @close="resetForm">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="86px">
        <el-form-item label="课程" prop="course_id">
          <el-select v-model="form.course_id" placeholder="选择课程" style="width:100%">
            <el-option
              v-for="course in courses"
              :key="course.course_id"
              :label="`${course.course_name} (${course.course_id}) - ${course.semester}`"
              :value="course.course_id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="日期" prop="teaching_date">
          <el-date-picker
            v-model="form.teaching_date"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择日期"
            style="width:100%"
          />
        </el-form-item>
        <el-form-item label="主题" prop="topic">
          <el-input v-model="form.topic" placeholder="如 SQL 聚合查询" />
        </el-form-item>
        <el-form-item label="课堂内容">
          <el-input v-model="form.content" type="textarea" :rows="4" />
        </el-form-item>
        <el-form-item label="课后任务">
          <el-input v-model="form.homework" type="textarea" :rows="3" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitLog">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import api from '@/api';
import { ElMessage, ElMessageBox } from 'element-plus';

const logs = ref([]);
const courses = ref([]);
const filterCourse = ref('');
const dialogVisible = ref(false);
const editingRow = ref(null);
const formRef = ref(null);

const today = () => new Date().toISOString().slice(0, 10);
const blankForm = () => ({
  course_id: '',
  teaching_date: today(),
  topic: '',
  content: '',
  homework: '',
  remark: ''
});

const form = ref(blankForm());
const rules = {
  course_id: [{ required: true, message: '请选择课程', trigger: 'change' }],
  teaching_date: [{ required: true, message: '请选择日期', trigger: 'change' }],
  topic: [{ required: true, message: '请输入主题', trigger: 'blur' }]
};

const loadCourses = async () => {
  const res = await api.get('/courses');
  courses.value = res.data.data;
};

const loadLogs = async () => {
  try {
    const params = filterCourse.value ? { course_id: filterCourse.value } : {};
    const res = await api.get('/teaching-logs', params);
    logs.value = res.data.data;
  } catch (error) {
    ElMessage.error(error.response?.data?.message || '获取教学日志失败');
  }
};

const openCreate = () => {
  editingRow.value = null;
  form.value = blankForm();
  if (filterCourse.value) {
    form.value.course_id = filterCourse.value;
  } else if (courses.value.length > 0) {
    form.value.course_id = courses.value[0].course_id;
  }
  dialogVisible.value = true;
};

const openEdit = (row) => {
  editingRow.value = row;
  form.value = {
    course_id: row.course_id,
    teaching_date: row.teaching_date,
    topic: row.topic,
    content: row.content || '',
    homework: row.homework || '',
    remark: row.remark || ''
  };
  dialogVisible.value = true;
};

const resetForm = () => {
  editingRow.value = null;
  form.value = blankForm();
};

const submitLog = async () => {
  if (!formRef.value) return;
  await formRef.value.validate(async (valid) => {
    if (!valid) return;
    try {
      if (editingRow.value) {
        await api.put(`/teaching-logs/${editingRow.value.id}`, form.value);
        ElMessage.success('教学日志已更新');
      } else {
        await api.post('/teaching-logs', form.value);
        ElMessage.success('教学日志已保存');
      }
      dialogVisible.value = false;
      loadLogs();
    } catch (error) {
      ElMessage.error(error.response?.data?.message || '保存教学日志失败');
    }
  });
};

const removeLog = async (row) => {
  try {
    await ElMessageBox.confirm(`确定删除 ${row.teaching_date} 的教学日志？`, '确认删除');
    await api.delete(`/teaching-logs/${row.id}`);
    ElMessage.success('教学日志已删除');
    loadLogs();
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(error.response?.data?.message || '删除教学日志失败');
    }
  }
};

onMounted(async () => {
  try {
    await loadCourses();
    await loadLogs();
  } catch (error) {
    ElMessage.error('初始化教学日志失败');
  }
});
</script>
