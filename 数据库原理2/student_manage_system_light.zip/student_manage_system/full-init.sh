#!/bin/bash

#############################################
# 学生选课成绩管理系统 - GaussDB/openGauss 初始化脚本
# 说明：请先在华为云创建 GaussDB/openGauss 实例和目标 database
#############################################

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_ENV="$PROJECT_DIR/backend/.env"
SQL_FILE="$PROJECT_DIR/database/schema-final.sql"
PROC_FILE="$PROJECT_DIR/database/sp-select-course.sql"

load_env_file() {
    if [ -f "$BACKEND_ENV" ]; then
        while IFS='=' read -r key value; do
            case "$key" in
                DB_HOST|DB_PORT|DB_USER|DB_PASSWORD|DB_NAME|DB_SSL|DB_SSL_REJECT_UNAUTHORIZED|JWT_SECRET)
                    if [ -z "${!key}" ]; then
                        export "$key=$value"
                    fi
                    ;;
            esac
        done < "$BACKEND_ENV"
    fi
}

find_db_client() {
    if command -v gsql >/dev/null 2>&1; then
        echo "gsql"
        return 0
    fi

    if command -v psql >/dev/null 2>&1; then
        echo "psql"
        return 0
    fi

    return 1
}

run_sql_file() {
    PGPASSWORD="$DB_PASSWORD" PGSSLMODE="$DB_SSL" "$DB_CLIENT" \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        -v ON_ERROR_STOP=1 \
        -f "$SQL_FILE"
}

run_procedure_file() {
    if [ "$DB_CLIENT" = "psql" ]; then
        local proc_sql
        proc_sql="$(sed '/^[[:space:]]*\/[[:space:]]*$/d' "$PROC_FILE")"
        PGPASSWORD="$DB_PASSWORD" PGSSLMODE="$DB_SSL" "$DB_CLIENT" \
            -h "$DB_HOST" \
            -p "$DB_PORT" \
            -U "$DB_USER" \
            -d "$DB_NAME" \
            -v ON_ERROR_STOP=1 \
            -c "$proc_sql"
        return
    fi

    PGPASSWORD="$DB_PASSWORD" PGSSLMODE="$DB_SSL" "$DB_CLIENT" \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        -v ON_ERROR_STOP=1 \
        -f "$PROC_FILE"
}

query_scalar() {
    PGPASSWORD="$DB_PASSWORD" PGSSLMODE="$DB_SSL" "$DB_CLIENT" \
        -h "$DB_HOST" \
        -p "$DB_PORT" \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        -Atc "$1"
}

load_env_file

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="${DB_PORT:-5432}"
DB_USER="${DB_USER:-student_user}"
DB_PASSWORD="${DB_PASSWORD:?请设置 DB_PASSWORD}"
DB_NAME="${DB_NAME:-school}"
DB_SSL="${DB_SSL:-disable}"
DB_SSL_REJECT_UNAUTHORIZED="${DB_SSL_REJECT_UNAUTHORIZED:-false}"
JWT_SECRET="${JWT_SECRET:-$(openssl rand -hex 32)}"

echo "================================================"
echo "  学生选课成绩管理系统 - GaussDB/openGauss 初始化"
echo "================================================"
echo ""
echo "连接信息："
echo "  Host：$DB_HOST"
echo "  Port：$DB_PORT"
echo "  Database：$DB_NAME"
echo "  User：$DB_USER"
echo "  SQL：$SQL_FILE"
echo "  Procedure：$PROC_FILE"
echo ""

if ! DB_CLIENT="$(find_db_client)"; then
    echo "✗ 未找到 gsql 或 psql 客户端"
    echo ""
    echo "可选做法："
    echo "  1. 安装 openGauss gsql 客户端后重新运行本脚本"
    echo "  2. 在华为云 DAS 中打开目标 database，手动执行：$SQL_FILE"
    exit 1
fi

echo "[1/4] 使用 $DB_CLIENT 初始化云端数据库..."
if run_sql_file; then
    echo "✓ 数据库对象初始化成功"
else
    echo "✗ 数据库初始化失败，请检查云数据库连接、安全组和账号权限"
    exit 1
fi

echo "  创建选课存储过程..."
if run_procedure_file; then
    echo "✓ 存储过程创建成功"
else
    echo "✗ 存储过程创建失败，请检查 openGauss 过程语法和账号权限"
    exit 1
fi

echo ""
echo "[2/4] 验证核心表..."
REQUIRED_TABLES=(admin student teacher course enrollment teaching_log)
MISSING_TABLES=()

for table in "${REQUIRED_TABLES[@]}"; do
    TABLE_EXISTS=$(query_scalar "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='public' AND table_name='$table';")
    if [ "$TABLE_EXISTS" -eq 0 ]; then
        MISSING_TABLES+=("$table")
    fi
done

if [ "${#MISSING_TABLES[@]}" -gt 0 ]; then
    echo "✗ 缺少表：${MISSING_TABLES[*]}"
    exit 1
fi

echo "✓ 核心表已就绪"
query_scalar "SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename;" | sed 's/^/  /'

echo ""
echo "[3/4] 验证数据、触发器和存储过程..."
ADMIN_COUNT=$(query_scalar "SELECT COUNT(*) FROM admin;")
STUDENT_COUNT=$(query_scalar "SELECT COUNT(*) FROM student;")
TEACHER_COUNT=$(query_scalar "SELECT COUNT(*) FROM teacher;")
COURSE_COUNT=$(query_scalar "SELECT COUNT(*) FROM course;")
ENROLLMENT_COUNT=$(query_scalar "SELECT COUNT(*) FROM enrollment;")
TEACHING_LOG_COUNT=$(query_scalar "SELECT COUNT(*) FROM teaching_log;")
TRIGGER_COUNT=$(query_scalar "SELECT COUNT(*) FROM information_schema.triggers WHERE trigger_schema='public' AND trigger_name IN ('trg_enrollment_after_insert', 'trg_enrollment_after_delete', 'trg_teaching_log_touch');")
PROCEDURE_COUNT=$(query_scalar "SELECT COUNT(*) FROM pg_proc WHERE proname='sp_select_course';")

echo "  管理员：$ADMIN_COUNT 个"
echo "  学生：$STUDENT_COUNT 个"
echo "  教师：$TEACHER_COUNT 个"
echo "  课程：$COURSE_COUNT 门"
echo "  选课：$ENROLLMENT_COUNT 条"
echo "  教学日志：$TEACHING_LOG_COUNT 条"
echo "  触发器：$TRIGGER_COUNT 个"
echo "  存储过程：$PROCEDURE_COUNT 个"

echo ""
echo "[4/4] 写入后端 GaussDB 连接配置..."
cat > "$BACKEND_ENV" << ENVEOF
PORT=3000
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
DB_NAME=$DB_NAME
DB_SSL=$DB_SSL
DB_SSL_REJECT_UNAUTHORIZED=$DB_SSL_REJECT_UNAUTHORIZED
JWT_SECRET=$JWT_SECRET
ENVEOF

echo "✓ 后端配置已更新：$BACKEND_ENV"

echo ""
echo "================================================"
echo "  ✓ 初始化完成"
echo "================================================"
echo "登录信息："
echo "  管理员：admin / 123456"
echo "  学生：2023001 / 123456"
echo "  教师：T001 / 123456"
echo ""
echo "启动服务：./launch.sh"
