#!/bin/bash

#############################################
# 学生选课成绩管理系统 - 启动脚本
# Student Course Management System - Launch Script
#############################################

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 项目根目录
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"

if [ -f "$BACKEND_DIR/.env" ]; then
    while IFS='=' read -r key value; do
        case "$key" in
            DB_HOST|DB_PORT|DB_USER|DB_PASSWORD|DB_NAME|DB_SSL|DB_SSL_REJECT_UNAUTHORIZED)
                export "$key=$value"
                ;;
        esac
    done < "$BACKEND_DIR/.env"
fi

APP_DB_HOST="${DB_HOST:-127.0.0.1}"
APP_DB_PORT="${DB_PORT:-5432}"
APP_DB_USER="${DB_USER:-student_user}"
APP_DB_PASSWORD="${DB_PASSWORD:-}"
APP_DB_NAME="${DB_NAME:-school}"

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║    学生选课成绩管理系统 - Launch Script                ║${NC}"
echo -e "${BLUE}║    Student Course Management System                    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# 检查 GaussDB/openGauss 连接
check_gaussdb() {
    echo -e "${YELLOW}[1/4] 检查 GaussDB/openGauss 连接...${NC}"

    local db_client=""
    if command -v gsql &> /dev/null; then
        db_client="gsql"
    elif command -v psql &> /dev/null; then
        db_client="psql"
    fi

    if [ -z "$db_client" ]; then
        echo -e "${YELLOW}⚠ 未安装 gsql/psql 客户端，跳过命令行数据库检查${NC}"
        echo -e "${YELLOW}  后端仍会在启动时使用 pg 驱动连接 GaussDB${NC}"
        return 1
    fi

    if PGPASSWORD="$APP_DB_PASSWORD" PGSSLMODE="${DB_SSL:-disable}" "$db_client" \
        -h "$APP_DB_HOST" \
        -p "$APP_DB_PORT" \
        -U "$APP_DB_USER" \
        -d "$APP_DB_NAME" \
        -Atc "SELECT 1;" >/dev/null 2>&1; then
        echo -e "${GREEN}✓ 后端账号可访问 GaussDB/openGauss 数据库 '$APP_DB_NAME'${NC}"
        return 0
    fi

    echo -e "${YELLOW}⚠ 后端账号无法访问 GaussDB/openGauss 数据库 '$APP_DB_NAME'${NC}"
    echo -e "${YELLOW}  请检查华为云安全组、白名单、账号密码，或运行：bash full-init.sh${NC}"
    return 1
}

# 检查 Node.js
check_node() {
    echo -e "${YELLOW}[2/4] 检查 Node.js 环境...${NC}"
    
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node -v)
        echo -e "${GREEN}✓ Node.js 已安装：$NODE_VERSION${NC}"
        return 0
    else
        echo -e "${RED}✗ Node.js 未安装，请先安装 Node.js${NC}"
        return 1
    fi
}

# 检查依赖
check_dependencies() {
    echo -e "${YELLOW}[3/4] 检查依赖...${NC}"
    
    local deps_ok=true
    
    # 检查后端依赖
    if [ -d "$BACKEND_DIR/node_modules" ]; then
        echo -e "${GREEN}✓ 后端依赖已安装${NC}"
    else
        echo -e "${YELLOW}正在安装后端依赖...${NC}"
        cd "$BACKEND_DIR" && npm install 2>&1 | tail -5
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✓ 后端依赖安装成功${NC}"
        else
            echo -e "${RED}✗ 后端依赖安装失败${NC}"
            deps_ok=false
        fi
    fi
    
    # 检查前端依赖
    if [ -d "$FRONTEND_DIR/node_modules" ]; then
        echo -e "${GREEN}✓ 前端依赖已安装${NC}"
    else
        echo -e "${YELLOW}正在安装前端依赖...${NC}"
        cd "$FRONTEND_DIR" && npm install 2>&1 | tail -5
        if [ $? -eq 0 ]; then
            echo -e "${GREEN}✓ 前端依赖安装成功${NC}"
        else
            echo -e "${RED}✗ 前端依赖安装失败${NC}"
            deps_ok=false
        fi
    fi
    
    if [ "$deps_ok" = false ]; then
        echo -e "${RED}依赖检查失败，请手动安装${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✓ 所有依赖检查完成${NC}"
}

# 启动后端服务
start_backend() {
    echo -e "${BLUE}启动后端服务...${NC}"
    cd "$BACKEND_DIR"
    
    # 启动后端（后台运行，输出到日志）
    nohup npm run dev > backend.log 2>&1 &
    local backend_pid=$!
    
    # 等待 5 秒检查是否启动成功
    sleep 5
    
    if ps -p $backend_pid > /dev/null; then
        # 检查端口是否监听
        if nc -z localhost 3000 2>/dev/null; then
            echo -e "${GREEN}✓ 后端服务启动成功 (PID: $backend_pid)${NC}"
            echo -e "  访问地址：http://localhost:3000"
            
            # 检查后端日志
            if grep -q "正在连接数据库" backend.log 2>/dev/null; then
                if grep -q "数据库连接成功" backend.log 2>/dev/null; then
                    echo -e "${GREEN}  数据库模式：GaussDB/openGauss${NC}"
                else
                    echo -e "${YELLOW}  数据库未连接：请运行 bash full-init.sh${NC}"
                fi
            fi
            return 0
        else
            echo -e "${RED}✗ 后端服务启动失败，请检查日志${NC}"
            tail -10 backend.log
            return 1
        fi
    else
        echo -e "${RED}✗ 后端服务启动失败${NC}"
        return 1
    fi
}

# 启动前端服务
start_frontend() {
    echo -e "${BLUE}启动前端服务...${NC}"
    cd "$FRONTEND_DIR"
    
    # 启动前端（后台运行，输出到日志）
    nohup npm run dev > frontend.log 2>&1 &
    local frontend_pid=$!
    
    # 等待 5 秒检查是否启动成功
    sleep 5
    
    if ps -p $frontend_pid > /dev/null; then
        # 获取实际使用的端口
        local port=$(grep -oP 'localhost:\K[0-9]+' frontend.log 2>/dev/null | tail -1)
        
        if [ -n "$port" ]; then
            echo -e "${GREEN}✓ 前端服务启动成功 (PID: $frontend_pid)${NC}"
            echo -e "  访问地址：http://localhost:$port"
            return 0
        else
            # 尝试检测端口
            for p in 5173 5174 5175 5176; do
                if nc -z localhost $p 2>/dev/null; then
                    echo -e "${GREEN}✓ 前端服务启动成功 (PID: $frontend_pid)${NC}"
                    echo -e "  访问地址：http://localhost:$p"
                    return 0
                fi
            done
            
            echo -e "${YELLOW}⚠ 前端服务可能启动中，请稍后查看日志${NC}"
            tail -5 frontend.log 2>/dev/null
            return 0
        fi
    else
        echo -e "${RED}✗ 前端服务启动失败，请检查日志${NC}"
        tail -5 frontend.log 2>/dev/null
        return 1
    fi
}

# 显示使用说明
show_help() {
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${YELLOW}使用说明:${NC}"
    echo -e "  1. 系统地址：[端口会自动检测] (前端)"
    echo -e "  2. API 地址：http://localhost:3000/api (后端)"
    echo -e "  3. 登录账号：admin / 123456"
    echo -e ""
    echo -e "${YELLOW}功能模块:${NC}"
    echo -e "  • 学生管理 - 增删改查学生信息"
    echo -e "  • 课程管理 - 增删改查课程信息与学期"
    echo -e "  • 选课管理 - 学生选课操作与学期筛选"
    echo -e "  • 退课管理 - 学生退课操作"
    echo -e "  • 成绩管理 - 录入和修改成绩"
    echo -e "  • 统计查询 - 查看学生、课程和教师统计数据"
    echo -e ""
    echo -e "${YELLOW}停止服务:${NC}"
    echo -e "  • 使用脚本：./stop.sh"
    echo -e "  • 手动停止：pkill -f 'npm run dev'"
    echo -e "  • 或查看进程：ps aux | grep 'npm run dev'"
    echo -e ""
    echo -e "${YELLOW}查看日志:${NC}"
    echo -e "  • 后端日志：tail -f backend/backend.log"
    echo -e "  • 前端日志：tail -f frontend/frontend.log"
    echo -e ""
    echo -e "${YELLOW}数据库管理:${NC}"
    echo -e "  • 初始化数据库：bash full-init.sh"
    echo -e "  • 数据库配置：backend/.env"
    echo -e ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# 主函数
main() {
    echo ""
    
    # 检查环境
    check_gaussdb
    local db_ready=$?
    check_node
    check_dependencies
    
    echo ""
    if [ "$db_ready" -eq 0 ]; then
        echo -e "${GREEN}✓ 环境检查完成，准备启动服务...${NC}"
    else
        echo -e "${YELLOW}⚠ 基础环境检查完成，但数据库账号可能不可用，后端启动后会再次检查连接${NC}"
    fi
    echo ""
    
    # 启动服务
    start_backend
    start_frontend
    
    echo ""
    show_help
    
    echo -e "${GREEN}服务已全部启动！${NC}"
    echo -e "${YELLOW}如需停止服务，使用：./stop.sh${NC}"
}

# 执行主函数
main
