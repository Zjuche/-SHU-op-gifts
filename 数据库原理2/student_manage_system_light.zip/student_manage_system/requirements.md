# 学生选课成绩管理系统 - 详细项目要求

> 基于教材《PowerBuilder 2018 数据库应用开发简介》第 13 章实验五
> 使用现代技术（Vue 3 + Node.js + 华为云 GaussDB/openGauss）实现

---

## 📌 项目定位

这是一个**学生选课成绩管理系统**，按照教材第 13 章实验要求开发，支持**三类用户角色**：管理员、学生、教师。

### ✅ 技术栈

- **前端**: Vue 3 + Vite + Element Plus + Pinia + Vue Router
- **后端**: Node.js + Express
- **数据库**: 华为云 GaussDB/openGauss
- **鉴权**: JWT Token

---

## 🎯 用户角色与权限

### 1. 管理员 (admin)

**账号**: `admin`  
**密码**: `123456`

**权限**:
- ✅ 学生管理 - 学生信息的增删改查
- ✅ 教师管理 - 教师信息的增删改查
- ✅ 课程管理 - 课程信息的增删改查
- ✅ 选课管理 - 为学生选课
- ✅ 退课管理 - 为学生退课
- ✅ 成绩管理 - 录入和修改学生成绩
- ✅ 统计查询 - 查看学生/课程成绩统计

---

### 2. 学生 (student)

**账号**: 学号（如 `2023001`）  
**密码**: `123456`

**权限**:
- ✅ 查看个人基本信息
- ✅ 查看个人选课列表
- ✅ 查看个人成绩
- ✅ 选课
- ✅ 退课

**无权限**:
- ❌ 不能修改学生信息
- ❌ 不能管理课程
- ❌ 不能录入成绩

---

### 3. 教师 (teacher)

**账号**: 教师工号（如 `T001`）  
**密码**: `123456`

**权限**:
- ✅ 查看个人基本信息
- ✅ 查看所授课程列表
- ✅ 查看所授课程的学生名单
- ✅ 录入所授课程的学生成绩
- ✅ 修改已有成绩

**无权限**:
- ❌ 不能修改学生/课程信息
- ❌ 不能选课/退课

---

## 📊 数据库表结构

### 1. admin 表（管理员表）

| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| id | INTEGER IDENTITY | 主键，自增 | 1 |
| username | VARCHAR(50) | 用户名（唯一） | admin |
| password | VARCHAR(100) | 密码 | 123456 |
| name | VARCHAR(50) | 姓名 | 系统管理员 |
| created_at | TIMESTAMP | 创建时间 | 2026-04-07 |

### 2. student 表（学生表）

| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| student_id | VARCHAR(20) | 学号（主键，登录账号） | 2023001 |
| name | VARCHAR(50) | 姓名 | 张明 |
| gender | VARCHAR(2) | 性别，CHECK 限制男/女 | 男 |
| age | SMALLINT | 年龄 | 20 |
| class_name | VARCHAR(50) | 班级 | 计科 2301 |
| major | VARCHAR(100) | 专业 | 计算机科学与技术 |
| phone | VARCHAR(20) | 电话 | 13800000001 |
| created_at | TIMESTAMP | 创建时间 | 2026-04-07 |

### 3. teacher 表（教师表）

| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| teacher_id | VARCHAR(20) | 教师工号（主键，登录账号） | T001 |
| name | VARCHAR(50) | 姓名 | 刘老师 |
| gender | VARCHAR(2) | 性别，CHECK 限制男/女 | 男 |
| title | VARCHAR(50) | 职称 | 副教授 |
| department | VARCHAR(100) | 所属院系 | 计算机学院 |
| phone | VARCHAR(20) | 电话 | 13900000001 |
| created_at | TIMESTAMP | 创建时间 | 2026-04-07 |

### 4. course 表（课程表）

| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| course_id | VARCHAR(20) | 课程号（主键） | C001 |
| course_name | VARCHAR(100) | 课程名 | 数据库原理 |
| credit | NUMERIC(3,1) | 学分 | 4.0 |
| teacher_id | VARCHAR(20) | 任课教师工号（外键） | T001 |
| teacher_name | VARCHAR(50) | 任课教师姓名 | 刘老师 |
| max_students | INTEGER | 最大人数 | 60 |
| classroom | VARCHAR(50) | 教室 | A201 |
| created_at | TIMESTAMP | 创建时间 | 2026-04-07 |

### 5. enrollment 表（选课表）

| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| id | INTEGER IDENTITY | 主键，自增 | 1 |
| student_id | VARCHAR(20) | 学号（外键） | 2023001 |
| course_id | VARCHAR(20) | 课程号（外键） | C001 |
| select_time | TIMESTAMP | 选课时间 | 2026-04-07 |
| score | NUMERIC(5,1) | 成绩（可为空） | 86.0 |

**约束**: 联合唯一约束 (student_id, course_id), 外键约束到 student 和 course 表

---

## 🔐 安全与鉴权

### JWT Token 认证

1. **登录流程**: 用户输入用户名和密码 → 后端验证 → 返回 JWT Token → 前端保存
2. **请求认证**: 每个请求在 Header 中携带 `Authorization: Bearer {token}`
3. **路由守卫**: 未登录自动跳转登录页，根据角色限制访问权限

---

## 🚀 当前状态

### ✅ 已完成

- ✅ 数据库创建（6 个表）
- ✅ 三类用户登录验证
- ✅ JWT Token 鉴权
- ✅ 前端路由守卫
- ✅ API 接口完整
- ✅ 后端 GaussDB/openGauss 连接支持

### 📊 系统运行

| 服务 | 状态 | 地址 |
|------|------|------|
| **后端** | ✅ 运行中 | http://localhost:3000 |
| **前端** | ✅ 运行中 | http://localhost:5173 |

### 🔑 测试账号

| 角色 | 账号 | 密码 |
|------|------|------|
| 管理员 | admin | 123456 |
| 学生 | 2023001-2023004 | 123456 |
| 教师 | T001-T003 | 123456 |

---

> **注意**: 所有用户初始密码均为 `123456`，实际项目中应使用加密存储（如 bcrypt）。
