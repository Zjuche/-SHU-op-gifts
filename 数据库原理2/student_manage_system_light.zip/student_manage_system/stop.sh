#!/bin/bash

#############################################
# 学生选课成绩管理系统 - 停止脚本
# Student Course Management System - Stop Script
#############################################

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║    学生选课成绩管理系统 - Stop Script                  ║${NC}"
echo -e "${BLUE}║    Student Course Management System                    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}"
echo ""

# 杀死占用指定端口的进程
kill_port() {
    local port=$1
    local pids=$(lsof -ti :$port 2>/dev/null)
    if [ -n "$pids" ]; then
        echo "$pids" | xargs kill -9 2>/dev/null
        return 0
    fi
    return 1
}

# 停止后端服务
stop_backend() {
    echo -e "${YELLOW}[1/2] 停止后端服务...${NC}"
    
    if lsof -ti :3000 &>/dev/null; then
        kill_port 3000
        sleep 1
        echo -e "${GREEN}✓ 后端服务已停止${NC}"
    else
        echo -e "${YELLOW}⚠ 后端服务未运行${NC}"
    fi
}

# 停止前端服务
stop_frontend() {
    echo -e "${YELLOW}[2/2] 停止前端服务...${NC}"
    
    local found=false
    for port in 5173 5174 5175 5176; do
        if lsof -ti :$port &>/dev/null; then
            kill_port $port
            found=true
        fi
    done
    
    if [ "$found" = true ]; then
        sleep 1
        echo -e "${GREEN}✓ 前端服务已停止${NC}"
    else
        echo -e "${YELLOW}⚠ 前端服务未运行${NC}"
    fi
}

# 检查端口是否被占用
check_ports() {
    echo -e "${YELLOW}检查端口占用...${NC}"
    
    if nc -z localhost 3000 2>/dev/null; then
        echo -e "${YELLOW}⚠ 端口 3000 (后端) 仍然被占用${NC}"
    else
        echo -e "${GREEN}✓ 端口 3000 已释放${NC}"
    fi
    
    if nc -z localhost 5173 2>/dev/null || nc -z localhost 5174 2>/dev/null || nc -z localhost 5175 2>/dev/null; then
        echo -e "${YELLOW}⚠ 前端端口 (5173/5174/5175) 仍然被占用${NC}"
    else
        echo -e "${GREEN}✓ 前端端口已释放${NC}"
    fi
}

# 清理日志文件
cleanup_logs() {
    echo -e "${YELLOW}清理日志文件...${NC}"
    
    local backend_log="backend/backend.log"
    local frontend_log="frontend/frontend.log"
    
    if [ -f "$backend_log" ]; then
        rm -f "$backend_log"
        echo -e "${GREEN}✓ 后端日志已清理${NC}"
    fi
    
    if [ -f "$frontend_log" ]; then
        rm -f "$frontend_log"
        echo -e "${GREEN}✓ 前端日志已清理${NC}"
    fi
}

# 主函数
main() {
    echo ""
    
    stop_backend
    stop_frontend
    
    echo ""
    check_ports
    
    echo ""
    cleanup_logs
    
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}✓ 所有服务已停止！${NC}"
    echo -e "${YELLOW}如需查看运行中的 Node 进程，使用：ps aux | grep node${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# 执行主函数
main
