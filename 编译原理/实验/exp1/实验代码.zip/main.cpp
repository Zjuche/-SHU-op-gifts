#include <algorithm>
#include <cctype>
#include <exception>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

struct Token {
    string type;
    string value;
};

class Lexer {
private:
    string src;
    size_t pos;
    vector<Token> tokens;
    vector<string> errors;
    map<string, string> keywords;
    map<char, string> singleCharTokens;

public:
    Lexer(const string &input) : src(input), pos(0) {
        keywords["begin"] = "beginsym";
        keywords["call"] = "callsym";
        keywords["const"] = "constsym";
        keywords["do"] = "dosym";
        keywords["end"] = "endsym";
        keywords["if"] = "ifsym";
        keywords["odd"] = "oddsym";
        keywords["procedure"] = "proceduresym";
        keywords["read"] = "readsym";
        keywords["then"] = "thensym";
        keywords["var"] = "varsym";
        keywords["while"] = "whilesym";
        keywords["write"] = "writesym";

        singleCharTokens['+'] = "plus";
        singleCharTokens['-'] = "minus";
        singleCharTokens['*'] = "times";
        singleCharTokens['/'] = "slash";
        singleCharTokens['='] = "eql";
        singleCharTokens['#'] = "neq";
        singleCharTokens['('] = "lparen";
        singleCharTokens[')'] = "rparen";
        singleCharTokens[','] = "comma";
        singleCharTokens[';'] = "semicolon";
        singleCharTokens['.'] = "period";
    }

    vector<Token> tokenize() {
        while (pos < src.size()) {
            unsigned char ch = static_cast<unsigned char>(src[pos]);

            if (isspace(ch)) {
                pos++;
                continue;
            }

            if (isalpha(ch)) {
                readWord();
            } else if (isdigit(ch)) {
                readNumber();
            } else if (src[pos] == ':') {
                readColonToken();
            } else if (src[pos] == '<') {
                readLessToken();
            } else if (src[pos] == '>') {
                readGreaterToken();
            } else if (singleCharTokens.count(src[pos])) {
                Token token;
                token.type = singleCharTokens[src[pos]];
                token.value = string(1, src[pos]);
                tokens.push_back(token);
                pos++;
            } else {
                errors.push_back("Lexical error: unknown character '" + string(1, src[pos]) +
                                 "' at position " + numberToString(pos));
                pos++;
            }
        }

        return tokens;
    }

    const vector<string> &getErrors() const {
        return errors;
    }

private:
    void readWord() {
        size_t start = pos;
        while (pos < src.size()) {
            unsigned char ch = static_cast<unsigned char>(src[pos]);
            if (!isalpha(ch) && !isdigit(ch)) {
                break;
            }
            pos++;
        }

        string word = src.substr(start, pos - start);
        string lowerWord = word;
        transform(lowerWord.begin(), lowerWord.end(), lowerWord.begin(),
                  toLowerChar);

        if (keywords.count(lowerWord)) {
            Token token;
            token.type = keywords[lowerWord];
            token.value = lowerWord;
            tokens.push_back(token);
        } else {
            Token token;
            token.type = "ident";
            token.value = lowerWord;
            tokens.push_back(token);
        }
    }

    void readNumber() {
        size_t start = pos;
        while (pos < src.size() && isdigit(static_cast<unsigned char>(src[pos]))) {
            pos++;
        }
        Token token;
        token.type = "number";
        token.value = src.substr(start, pos - start);
        tokens.push_back(token);
    }

    void readColonToken() {
        if (pos + 1 < src.size() && src[pos + 1] == '=') {
            Token token;
            token.type = "becomes";
            token.value = ":=";
            tokens.push_back(token);
            pos += 2;
            return;
        }

        errors.push_back("Lexical error: ':' must be followed by '=' at position " +
                         numberToString(pos));
        pos++;
    }

    void readLessToken() {
        if (pos + 1 < src.size() && src[pos + 1] == '=') {
            Token token;
            token.type = "leq";
            token.value = "<=";
            tokens.push_back(token);
            pos += 2;
        } else {
            Token token;
            token.type = "lss";
            token.value = "<";
            tokens.push_back(token);
            pos++;
        }
    }

    void readGreaterToken() {
        if (pos + 1 < src.size() && src[pos + 1] == '=') {
            Token token;
            token.type = "geq";
            token.value = ">=";
            tokens.push_back(token);
            pos += 2;
        } else {
            Token token;
            token.type = "gtr";
            token.value = ">";
            tokens.push_back(token);
            pos++;
        }
    }

    static char toLowerChar(char c) {
        return static_cast<char>(tolower(static_cast<unsigned char>(c)));
    }

    static string numberToString(size_t value) {
        ostringstream out;
        out << value;
        return out.str();
    }
};

string readFile(const string &filename) {
    ifstream fin(filename);
    if (!fin.is_open()) {
        throw runtime_error("Cannot open input file: " + filename);
    }

    return string((istreambuf_iterator<char>(fin)), istreambuf_iterator<char>());
}

void writeTokens(const string &filename, const vector<Token> &tokens) {
    ofstream fout(filename);
    if (!fout.is_open()) {
        throw runtime_error("Cannot open output file: " + filename);
    }

    size_t i;
    for (i = 0; i < tokens.size(); ++i) {
        fout << "(" << tokens[i].type << "," << tokens[i].value << ")" << '\n';
    }
}

int main(int argc, char *argv[]) {
    try {
        if (argc != 3) {
            cerr << "Usage: " << argv[0] << " <input_file> <output_file>" << endl;
            return 1;
        }

        string inputFile = argv[1];
        string outputFile = argv[2];

        string input = readFile(inputFile);
        Lexer lexer(input);
        vector<Token> tokens = lexer.tokenize();
        writeTokens(outputFile, tokens);

        const vector<string> &errors = lexer.getErrors();
        size_t i;
        for (i = 0; i < errors.size(); ++i) {
            cerr << errors[i] << '\n';
        }

        if (lexer.getErrors().empty()) {
            cout << "Lexical analysis finished. Check " << outputFile << endl;
        } else {
            cout << "Lexical analysis finished with errors. Check " << outputFile << endl;
        }
    } catch (const exception &e) {
        cerr << e.what() << endl;
        return 1;
    }

    return 0;
}
