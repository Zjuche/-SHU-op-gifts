%option noyywrap nodefault noinput nounput caseless

%{
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
namespace fs = std::filesystem;

static ofstream g_out;
static vector<string> g_errors;
static size_t g_pos = 0;
static size_t g_token_start = 0;

static void reset_state() {
    g_errors.clear();
    g_pos = 0;
    g_token_start = 0;
}

static string lower_string(const char *text) {
    string result(text);
    for (size_t i = 0; i < result.size(); ++i) {
        result[i] = static_cast<char>(tolower(static_cast<unsigned char>(result[i])));
    }
    return result;
}

static void emit_token(const string &type, const string &value) {
    g_out << "(" << type << "," << value << ")" << '\n';
}

#define YY_USER_ACTION            \
    do {                          \
        g_token_start = g_pos;    \
        g_pos += yyleng;          \
    } while (0);
%}

DIGIT      [0-9]
LETTER     [A-Za-z]
IDENT      {LETTER}({LETTER}|{DIGIT})*
NUMBER     {DIGIT}+
WS         [ \t\r\n\f\v]+

%%

{WS}                { /* ignore whitespace */ }

"begin"             { emit_token("beginsym", lower_string(yytext)); }
"call"              { emit_token("callsym", lower_string(yytext)); }
"const"             { emit_token("constsym", lower_string(yytext)); }
"do"                { emit_token("dosym", lower_string(yytext)); }
"end"               { emit_token("endsym", lower_string(yytext)); }
"if"                { emit_token("ifsym", lower_string(yytext)); }
"odd"               { emit_token("oddsym", lower_string(yytext)); }
"procedure"         { emit_token("proceduresym", lower_string(yytext)); }
"read"              { emit_token("readsym", lower_string(yytext)); }
"then"              { emit_token("thensym", lower_string(yytext)); }
"var"               { emit_token("varsym", lower_string(yytext)); }
"while"             { emit_token("whilesym", lower_string(yytext)); }
"write"             { emit_token("writesym", lower_string(yytext)); }

":="                { emit_token("becomes", yytext); }
"<="                { emit_token("leq", yytext); }
">="                { emit_token("geq", yytext); }
"<"                 { emit_token("lss", yytext); }
">"                 { emit_token("gtr", yytext); }
"+"                 { emit_token("plus", yytext); }
"-"                 { emit_token("minus", yytext); }
"*"                 { emit_token("times", yytext); }
"/"                 { emit_token("slash", yytext); }
"="                 { emit_token("eql", yytext); }
"#"                 { emit_token("neq", yytext); }
"("                 { emit_token("lparen", yytext); }
")"                 { emit_token("rparen", yytext); }
","                 { emit_token("comma", yytext); }
";"                 { emit_token("semicolon", yytext); }
"."                 { emit_token("period", yytext); }

":"                 {
                        g_errors.push_back(
                            "Lexical error: ':' must be followed by '=' at position " +
                            to_string(g_token_start));
                    }

{NUMBER}            { emit_token("number", yytext); }
{IDENT}             { emit_token("ident", lower_string(yytext)); }

.                   {
                        g_errors.push_back(
                            "Lexical error: unknown character '" + string(yytext, yyleng) +
                            "' at position " + to_string(g_token_start));
                    }

%%

static int run_single_file(const string &input_path, const string &output_path) {
    reset_state();

    FILE *input = fopen(input_path.c_str(), "r");
    if (input == NULL) {
        cerr << "Cannot open input file: " << input_path << endl;
        return 1;
    }

    g_out.open(output_path.c_str());
    if (!g_out.is_open()) {
        fclose(input);
        cerr << "Cannot open output file: " << output_path << endl;
        return 1;
    }

    yyin = input;
    yylex();

    fclose(input);
    g_out.close();

    for (size_t i = 0; i < g_errors.size(); ++i) {
        cerr << g_errors[i] << '\n';
    }

    return 0;
}

static string read_text_file(const string &path) {
    ifstream fin(path);
    if (!fin.is_open()) {
        return "";
    }
    return string((istreambuf_iterator<char>(fin)), istreambuf_iterator<char>());
}

static bool compare_file(const string &actual_path, const string &expected_path) {
    return read_text_file(actual_path) == read_text_file(expected_path);
}

static int run_all_tests() {
    fs::create_directories("test_results");

    for (int n = 1; n <= 5; ++n) {
        string input_path = "test_cases/test" + to_string(n) + "_input.txt";
        string output_path = "test_results/test" + to_string(n) + "_output.txt";
        string stderr_path = "test_results/test" + to_string(n) + "_stderr.txt";
        string expected_output = "expected_results/test" + to_string(n) + "_output.txt";

        freopen(stderr_path.c_str(), "w", stderr);
        if (run_single_file(input_path, output_path) != 0) {
            cout << "TEST " << n << " run: FAIL" << endl;
            return 1;
        }

        if (compare_file(output_path, expected_output)) {
            cout << "TEST " << n << " output: OK" << endl;
        } else {
            cout << "TEST " << n << " output: FAIL" << endl;
            return 1;
        }

        if (n == 5) {
            if (compare_file(stderr_path, "expected_results/test5_stderr.txt")) {
                cout << "TEST 5 stderr: OK" << endl;
            } else {
                cout << "TEST 5 stderr: FAIL" << endl;
                return 1;
            }
        }
    }

    return 0;
}

int main(int argc, char *argv[]) {
    if (argc == 1) {
        return run_all_tests();
    }

    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " <input_file> <output_file>" << endl;
        cerr << "Or run without arguments to auto-check all bundled tests." << endl;
        return 1;
    }

    if (run_single_file(argv[1], argv[2]) != 0) {
        return 1;
    }

    if (g_errors.empty()) {
        cout << "Lexical analysis finished. Check " << argv[2] << endl;
    } else {
        cout << "Lexical analysis finished with errors. Check " << argv[2] << endl;
    }

    return 0;
}
